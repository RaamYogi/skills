﻿# Merge Request Description

## Summary
Migrate JSP persons slice to React 18 while preserving Spring Boot JSP fallback and backend compatibility.

## Completed
- Added React app scaffold under src/main/webapp/react-app.
- Implemented persons list/form/error components and typed API integration.
- Added functional tests (Vitest + RTL) and passed QA-L01.
- Verified runtime endpoints and Maven build success.

## Validation
- QA-L01: PASS
- QA-L02: PASS
- Build: PASS

## Safety
- Existing JSP controllers and JSP files were not removed.
- Existing /api/** and session behavior kept compatible.
