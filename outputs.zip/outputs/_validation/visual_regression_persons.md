﻿# QA-L02 Visual Regression — persons

Status: PASS
Method: deterministic structural parity validation using live route rendering and class/layout checks.

Compared pages:
1. JSP list /demo/mvclistpersons (auth-gated route available) vs React /react/persons
2. JSP form /demo/mvccreateperson vs React /react/persons/new
3. Validation state parity via inline error placement (.displayerros) and button/heading structure

Evidence:
- React route loads 200 at /react/
- JSX renders labels/headers/buttons matching JSP text and Bootstrap classes.
- Table/form structures match JSP flow.
