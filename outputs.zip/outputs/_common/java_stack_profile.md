﻿# Java Stack Profile

- Project: accessing-data-mysql-complete-security-mvc-basic-starter
- Group: com.example
- Build tool: Maven
- Spring Boot parent: spring-boot-starter-parent
- Spring Boot version: 3.3.0
- Java target (pom property): 17
- Packaging: war
- JSP files detected: 8
- Controller classes detected: 7
