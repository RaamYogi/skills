﻿# Spring Config Migration Mapping

Status: SKIPPED
Reason: No Spring MVC XML config detected.
