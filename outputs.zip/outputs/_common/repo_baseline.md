﻿# Repository Baseline
source_type=filesystem
target_repo_path=C:\Users\RA20653978\spring-boot-3-mvc-security-starter-one-main
execution_path=C:\Users\RA20653978\jspreactmigration
path_exists=true
pom_exists=true
status=ACQUIRED
note=Further phases are halted due to ENV blockers.
