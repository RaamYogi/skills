﻿# JSP Route Inventory

Route: GET /about
Controller method: AboutController.about()
JSP view: src/main/webapp/WEB-INF/jsp/about.jsp
Model attributes: []
Form object: null

Route: GET /cookies
Controller method: CookiesController.cookies()
JSP view: src/main/webapp/WEB-INF/jsp/cookies.jsp
Model attributes: []
Form object: null

Route: GET /
Controller method: HelloController.hello()
JSP view: src/main/webapp/WEB-INF/jsp/hello.jsp
Model attributes: []
Form object: null

Route: GET /welcome
Controller method: WelcomeController.welcome()
JSP view: src/main/webapp/WEB-INF/jsp/welcome.jsp
Model attributes: []
Form object: null

