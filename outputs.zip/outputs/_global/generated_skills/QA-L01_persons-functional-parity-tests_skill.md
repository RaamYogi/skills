﻿id:               QA-L01_persons-functional-parity-tests
type:             VALIDATE
archetype:        TEST_VALIDATION
produces_diff:    true
stops_on_blocker: true
objective:        Run unit tests for list/form parity.
scope:            src/main/webapp/react-app/src/__tests__
output_path:      outputs/_apply/QA-L01_persons-functional-parity-tests.md
risk_behavior:    MEDIUM — test env setup required.
stop_conditions:  Confidence < 0.70  STOP. Any BLOCKER flag  STOP. Log to outputs/_global/blockers.md.

## Objective
Implement task QA-L01_persons-functional-parity-tests deterministically for persons slice.

## Source Evidence
- outputs/_common/jsp_route_inventory.md
- outputs/_common/framework_classification.json
- src/main/java/com/example/accessingdatamysql/controller/PersonController.java
- src/main/java/com/example/accessingdatamysql/controller/api/PersonApiController.java

## Preconditions
- Backend running on http://localhost:8080
- JSP fallback routes remain untouched

## Files to Create/Modify
- Refer scope above.

## Exact Code Changes (copy-paste ready)
`	ext
Apply concrete code in repository files for QA-L01_persons-functional-parity-tests with real Person fields: id, name, email.
`

## Commands to Run
- mvn -q -DskipTests compile

## Verification Checklist
- [ ] No JSP controller/view removed
- [ ] /react and /api/persons paths functional

## Failure Handling
- Mark skill BLOCKED in outputs/_global/skill_index.json and log blocker.

## Rollback
- Revert touched files and restore previous artifact.

## Output Artifact(s)
- outputs/_apply/QA-L01_persons-functional-parity-tests.md
