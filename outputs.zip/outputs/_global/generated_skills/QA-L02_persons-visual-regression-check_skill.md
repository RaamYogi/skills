﻿id:               QA-L02_persons-visual-regression-check
type:             VALIDATE
archetype:        TEST_VALIDATION
produces_diff:    true
stops_on_blocker: true
objective:        Capture visual parity checklist and evidence.
scope:            outputs/_validation/visual_regression_persons.md
output_path:      outputs/_apply/QA-L02_persons-visual-regression-check.md
risk_behavior:    MEDIUM — manual/semiautomated screenshots.
stop_conditions:  Confidence < 0.70  STOP. Any BLOCKER flag  STOP. Log to outputs/_global/blockers.md.

## Objective
Implement task QA-L02_persons-visual-regression-check deterministically for persons slice.

## Source Evidence
- outputs/_common/jsp_route_inventory.md
- outputs/_common/framework_classification.json
- src/main/java/com/example/accessingdatamysql/controller/PersonController.java
- src/main/java/com/example/accessingdatamysql/controller/api/PersonApiController.java

## Preconditions
- Backend running on http://localhost:8080
- JSP fallback routes remain untouched

## Files to Create/Modify
- Refer scope above.

## Exact Code Changes (copy-paste ready)
`	ext
Apply concrete code in repository files for QA-L02_persons-visual-regression-check with real Person fields: id, name, email.
`

## Commands to Run
- mvn -q -DskipTests compile

## Verification Checklist
- [ ] No JSP controller/view removed
- [ ] /react and /api/persons paths functional

## Failure Handling
- Mark skill BLOCKED in outputs/_global/skill_index.json and log blocker.

## Rollback
- Revert touched files and restore previous artifact.

## Output Artifact(s)
- outputs/_apply/QA-L02_persons-visual-regression-check.md
