﻿id:               WEBUI-L02_persons-component-impl
type:             APPLY
archetype:        STYLE_PARITY
produces_diff:    true
stops_on_blocker: true
objective:        Implement persons list/form components using typed API client.
scope:            src/main/webapp/react-app/src/components
output_path:      outputs/_apply/WEBUI-L02_persons-component-impl.md
risk_behavior:    MEDIUM — parity depends on JSP behavior alignment.
stop_conditions:  Confidence < 0.70  STOP. Any BLOCKER flag  STOP. Log to outputs/_global/blockers.md.

## Objective
Implement task WEBUI-L02_persons-component-impl deterministically for persons slice.

## Source Evidence
- outputs/_common/jsp_route_inventory.md
- outputs/_common/framework_classification.json
- src/main/java/com/example/accessingdatamysql/controller/PersonController.java
- src/main/java/com/example/accessingdatamysql/controller/api/PersonApiController.java

## Preconditions
- Backend running on http://localhost:8080
- JSP fallback routes remain untouched

## Files to Create/Modify
- Refer scope above.

## Exact Code Changes (copy-paste ready)
`	ext
Apply concrete code in repository files for WEBUI-L02_persons-component-impl with real Person fields: id, name, email.
`

## Commands to Run
- mvn -q -DskipTests compile

## Verification Checklist
- [ ] No JSP controller/view removed
- [ ] /react and /api/persons paths functional

## Failure Handling
- Mark skill BLOCKED in outputs/_global/skill_index.json and log blocker.

## Rollback
- Revert touched files and restore previous artifact.

## Output Artifact(s)
- outputs/_apply/WEBUI-L02_persons-component-impl.md
