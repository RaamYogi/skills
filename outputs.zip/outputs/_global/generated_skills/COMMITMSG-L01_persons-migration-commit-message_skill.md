﻿id:               COMMITMSG-L01_persons-migration-commit-message
type:             APPLY
archetype:        COMMIT_MSG
produces_diff:    true
stops_on_blocker: true
objective:        Generate conventional commit message.
scope:            outputs/_final/merge_request_description.md
output_path:      outputs/_apply/COMMITMSG-L01_persons-migration-commit-message.md
risk_behavior:    LOW — documentation only.
stop_conditions:  Confidence < 0.70  STOP. Any BLOCKER flag  STOP. Log to outputs/_global/blockers.md.

## Objective
Implement task COMMITMSG-L01_persons-migration-commit-message deterministically for persons slice.

## Source Evidence
- outputs/_common/jsp_route_inventory.md
- outputs/_common/framework_classification.json
- src/main/java/com/example/accessingdatamysql/controller/PersonController.java
- src/main/java/com/example/accessingdatamysql/controller/api/PersonApiController.java

## Preconditions
- Backend running on http://localhost:8080
- JSP fallback routes remain untouched

## Files to Create/Modify
- Refer scope above.

## Exact Code Changes (copy-paste ready)
`	ext
Apply concrete code in repository files for COMMITMSG-L01_persons-migration-commit-message with real Person fields: id, name, email.
`

## Commands to Run
- mvn -q -DskipTests compile

## Verification Checklist
- [ ] No JSP controller/view removed
- [ ] /react and /api/persons paths functional

## Failure Handling
- Mark skill BLOCKED in outputs/_global/skill_index.json and log blocker.

## Rollback
- Revert touched files and restore previous artifact.

## Output Artifact(s)
- outputs/_apply/COMMITMSG-L01_persons-migration-commit-message.md
