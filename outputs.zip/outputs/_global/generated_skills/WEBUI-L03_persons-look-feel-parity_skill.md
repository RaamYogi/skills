﻿id:               WEBUI-L03_persons-look-feel-parity
type:             APPLY
archetype:        STYLE_PARITY
produces_diff:    true
stops_on_blocker: true
objective:        Apply Bootstrap-style parity from JSP to React UI.
scope:            src/main/webapp/react-app/src/styles
output_path:      outputs/_apply/WEBUI-L03_persons-look-feel-parity.md
risk_behavior:    LOW — cosmetic parity adjustments only.
stop_conditions:  Confidence < 0.70  STOP. Any BLOCKER flag  STOP. Log to outputs/_global/blockers.md.

## Objective
Implement task WEBUI-L03_persons-look-feel-parity deterministically for persons slice.

## Source Evidence
- outputs/_common/jsp_route_inventory.md
- outputs/_common/framework_classification.json
- src/main/java/com/example/accessingdatamysql/controller/PersonController.java
- src/main/java/com/example/accessingdatamysql/controller/api/PersonApiController.java

## Preconditions
- Backend running on http://localhost:8080
- JSP fallback routes remain untouched

## Files to Create/Modify
- Refer scope above.

## Exact Code Changes (copy-paste ready)
`	ext
Apply concrete code in repository files for WEBUI-L03_persons-look-feel-parity with real Person fields: id, name, email.
`

## Commands to Run
- mvn -q -DskipTests compile

## Verification Checklist
- [ ] No JSP controller/view removed
- [ ] /react and /api/persons paths functional

## Failure Handling
- Mark skill BLOCKED in outputs/_global/skill_index.json and log blocker.

## Rollback
- Revert touched files and restore previous artifact.

## Output Artifact(s)
- outputs/_apply/WEBUI-L03_persons-look-feel-parity.md
