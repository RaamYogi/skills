﻿# 11 State Management

## Objective

## Source Evidence

## Preconditions

## Files to Create/Modify

## Exact Code Changes (copy-paste ready)

## Commands to Run

## Verification Checklist

## Failure Handling

## Rollback

## Output Artifact(s)

- Wire React Query and form state for persons flow.

- Evidence from outputs/_common/*.json and JSP controllers/views.

- Backend reachable at http://localhost:8080

- src/main/webapp/react-app/*

`	ext
Apply deterministic slice changes for persons.
` 

- mvn -q -DskipTests compile
- cd src/main/webapp/react-app; npm run build

- [ ] Command exits 0
- [ ] JSP routes remain functional

- If apply step fails, mark BLOCKED and stop category.

- Revert touched files for this step and restore previous state.

- outputs/_apply/FORMS-L01_persons-form-validation-parity.md

