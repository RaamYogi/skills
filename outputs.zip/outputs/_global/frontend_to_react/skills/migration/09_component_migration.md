﻿# 09 Component Migration

## Objective

## Source Evidence

## Preconditions

## Files to Create/Modify

## Exact Code Changes (copy-paste ready)

## Commands to Run

## Verification Checklist

## Failure Handling

## Rollback

## Output Artifact(s)

- Implement persons list/form components with parity.

- Evidence from outputs/_common/*.json and JSP controllers/views.

- Backend reachable at http://localhost:8080

- src/main/webapp/react-app/*

`	ext
Apply deterministic slice changes for persons.
` 

- mvn -q -DskipTests compile
- cd src/main/webapp/react-app; npm run build

- [ ] Command exits 0
- [ ] JSP routes remain functional

- If apply step fails, mark BLOCKED and stop category.

- Revert touched files for this step and restore previous state.

- outputs/_apply/WEBUI-L02_persons-component-impl.md

