﻿# Frontend to React Skill Pack Overview

Deterministic JSP-to-React skill pack for persons slice.
