﻿# Blockers

No active blockers.

Waiver:
- ENV-04 (git availability) waived by operator instruction: "git ignore for now".
