﻿# Generated WBS — JSP to React Migration

## 1) Summary
- Slice: persons (List / Form / Save / Delete)
- Source frontend: JSP
- Target frontend: React 18 + TypeScript + Vite
- Backend strategy: keep existing MVC controllers and JSP fallback active; add/retain REST APIs only.

## 2) High-Level Tasks
- CONTRACT-H01 Contract extraction for persons slice
- API-H01 REST contract and endpoint execution for persons slice
- WEBUI-H01 React host and component migration for persons slice
- FORMS-H01 React form and validation parity for persons slice
- COMPAT-H01 Session/auth/cors/error parity tasks
- QA-H01 Functional and visual parity validation
- STATE-H01 Migration state checkpoint
- COMMITMSG-H01 Conventional commit generation

## 3) Low-Level Tasks
- CONTRACT-L01_persons-dto-field-mapping
  - Phase: PLAN
  - Notes: Map `${person.id}`, `${person.name}`, `${person.email}` and form fields to DTOs.
  - Structured Skill Mapping: analysis/01_baseline_analysis.md, analysis/02_component_mapping.md

- CONTRACT-L02_persons-jstl-data-mock
  - Phase: SCAN
  - Notes: Extract fixture-equivalent data shape for React mock mode.
  - Structured Skill Mapping: analysis/03_api_dependency_scan.md, analysis/04_state_management_analysis.md

- API-L01_persons-endpoint-plan
  - Phase: PLAN
  - Notes: Confirm `/api/persons` GET, `/api/persons/{id}` GET, `/api/persons` POST, `/api/persons/{id}` DELETE.
  - Structured Skill Mapping: analysis/05_migration_planning.md, migration/06_rest_api_creation.md

- API-L02_persons-endpoint-impl
  - Phase: APPLY
  - Notes: Use existing `PersonApiController` and enforce response/error parity.
  - Structured Skill Mapping: migration/06_rest_api_creation.md

- WEBUI-L01_react-host-scaffold
  - Phase: APPLY
  - Notes: Scaffold React app under `src/main/webapp/react-app` and route `/react/**`.
  - Structured Skill Mapping: migration/08_react_setup.md, migration/10_routing_migration.md

- WEBUI-L02_persons-component-impl
  - Phase: APPLY
  - Notes: Build list and form React components with typed API client.
  - Structured Skill Mapping: migration/09_component_migration.md, migration/11_state_management.md

- WEBUI-L03_persons-look-feel-parity
  - Phase: APPLY
  - Notes: Match table/form layout and bootstrap styling from JSP.
  - Structured Skill Mapping: migration/09_component_migration.md

- FORMS-L01_persons-form-validation-parity
  - Phase: APPLY
  - Notes: React Hook Form + Zod for name/email with inline errors.
  - Structured Skill Mapping: migration/11_state_management.md, validation/13_testing_setup.md

- FORMS-L02_persons-redirect-nav-parity
  - Phase: APPLY
  - Notes: Match JSP redirect to list after save/delete.
  - Structured Skill Mapping: migration/10_routing_migration.md, migration/12_integration_bridge.md

- COMPAT-L01_session-auth-compat
  - Phase: APPLY
  - Notes: `credentials:'include'`, CORS and CSRF compatible calls.
  - Structured Skill Mapping: migration/07_cors_configuration.md, migration/12_integration_bridge.md

- COMPAT-L02_error-page-parity
  - Phase: APPLY
  - Notes: React error fallback for 404/500 paths.
  - Structured Skill Mapping: validation/14_build_integration.md

- QA-L01_persons-functional-parity-tests
  - Phase: VALIDATE
  - Notes: Vitest + RTL tests for list render, form validation, submit flow.
  - Structured Skill Mapping: validation/13_testing_setup.md

- QA-L02_persons-visual-regression-check
  - Phase: VALIDATE
  - Notes: Side-by-side JSP vs React screenshots and parity checklist.
  - Structured Skill Mapping: validation/15_deployment_validation.md

- STATE-L01_persons-migration-state-checkpoint
  - Phase: VALIDATE
  - Notes: Persist status/results in migration state.
  - Structured Skill Mapping: validation/14_build_integration.md

- COMMITMSG-L01_persons-migration-commit-message
  - Phase: APPLY
  - Notes: Conventional commit draft with changed files and QA result.
  - Structured Skill Mapping: validation/15_deployment_validation.md
