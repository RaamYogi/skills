# Common Module: Route Inventory Builder

Purpose: Build a deterministic inventory of frontend routes/views by dispatching to JSP or Angular detection logic based on frontend_scan.json. Replaces the previously improvised "Build JSP route inventory" step.
Phase: SCAN
Output: outputs/_common/route_inventory.md

Inputs:
- outputs/_common/frontend_scan.json
- outputs/_common/repo_scan.json
- execution.source_code_path (from migration_config.yaml)

Dispatch Rules:
- If frontend_scan.type = "jsp"     → execute JSP Route Detection (see below).
- If frontend_scan.type = "angular" → execute Angular Route Detection (see below).
- If frontend_scan.type = "hybrid"  → execute both; label each section clearly.
- If frontend_scan.type = "unknown" → write empty inventory and STOP.

---

## JSP Route Detection

Sources:
1. All .jsp files under src/main/webapp/WEB-INF/jsp/ (recursive).
2. Spring MVC controllers: scan Java files for @RequestMapping, @GetMapping, @PostMapping, @PutMapping, @DeleteMapping annotations.
3. Match each .jsp view to its controller method by view name returned from the method (ModelAndView, return "string", or InternalResourceViewResolver prefix/suffix patterns).

Per-route fields:
- route_path: URL path from @RequestMapping (e.g., "/owners/find")
- http_method: GET|POST|PUT|DELETE|ANY
- controller_class: fully qualified class name
- controller_method: method name
- view_name: logical view name returned
- jsp_file: relative path to .jsp file
- form_fields: list of form input field names from .jsp (name attributes from <form:input>, <input>, etc.)
- model_attributes: list of @ModelAttribute or Model.addAttribute keys in controller method
- validation: true if @Valid or @Validated present on any method parameter
- redirect_targets: list of "redirect:" prefixed return values in controller method
- notes: any flags (e.g., "multi-result redirect", "form binding")

---

## Angular Route Detection

Sources:
1. RouterModule.forRoot([...]) or RouterModule.forChild([...]) declarations in any .ts file.
2. loadChildren (lazy-loaded routes) strings.
3. @Component selector and templateUrl/template from each component matched to a route.

Per-route fields:
- route_path: path string from route definition (e.g., "owners/find")
- component_class: Angular component class name
- component_file: relative path to .ts component file
- template_file: relative path to .html template file (or "inline" if template is inline)
- lazy_loaded: true|false
- form_type: "reactive"|"template"|"none"
- http_calls: list of HttpClient calls made in the component or its injected services
- guard: route guard class name if any (CanActivate, etc.)
- notes: any flags

---

## Output Format (Markdown with structured tables)

```
# Route Inventory
Frontend Type: <jsp|angular|hybrid>

## Summary
Total routes: <n>

## Routes

### <route_path> [<http_method>]
- controller_class / component_class: <value>
- controller_method / component_file: <value>
- view_name / template_file: <value>
- form_fields: [field1, field2]
- validation: <true|false>
- redirect_targets / guard: <value>
- notes: <value>
```

Stop Conditions:
- If frontend_scan.type = "unknown", write empty file and STOP.
- If no routes are found, write "No routes detected." and set Total routes: 0. Do not STOP.

Action:
- Read frontend_scan.json to determine dispatch.
- Scan source tree per detection rules above.
- Write route inventory to outputs/_common/route_inventory.md.
- Produce the artifact even if empty.
