# Common Module: Migration State Checkpoint

Purpose: Maintain a deterministic migration state snapshot after each phase or module set.
Phase: PLAN
Output: core/state/migration_state.json

Inputs:
- migration_config.yaml
- outputs/_global/module_reports/*.md
- outputs/_final/merge_request_description.md

Constraints:
- Deterministic output with stable ordering.
- Do not infer beyond evidence; use "unknown" if unclear.
- Phase 1 targets: Spring 5, JDK 17, Tomcat 9.
- Phase 2 targets: Spring 6, JDK 17 or 21, Tomcat 10.

Output JSON Schema:
{
  "state_version": "1.0",
  "phase": "<SPRING5|SPRING6|UNKNOWN>",
  "phase1": {
    "spring_target": "<string>",
    "java_target": "<string>",
    "container_target": "tomcat9",
    "build_status": "<PASS|FAIL|NOT_RUN>",
    "runtime_status": "<PASS|FAIL|NOT_RUN>",
    "notes": "<string>"
  },
  "phase2": {
    "spring_target": "<string>",
    "java_target": "<string>",
    "java_target_options": ["<string>"],
    "container_target": "tomcat10",
    "build_status": "<PASS|FAIL|NOT_RUN>",
    "runtime_status": "<PASS|FAIL|NOT_RUN>",
    "notes": "<string>"
  },
  "docker": {
    "phase1_ready": "<true|false>",
    "phase2_ready": "<true|false>",
    "requirements": ["<string>"]
  },
  "evidence": ["<string>"],
  "known_unknowns": ["<string>"],
  "notes": "<string>"
}

Rules:
- spring_target values must use migration_config.yaml targets where available.
- phase1.java_target should use migration_config.yaml targets.java_version.
- phase2.java_target should use targets.java_version unless a higher version is explicitly declared; if 21 is desired but not set, add to java_target_options and list in known_unknowns.
- Determine build_status by reading module reports:
  - For Phase 1, use JAVA, SPRINGX, HIBERNATE, STRUTS, JSPVIEW build validation statuses.
  - For Phase 2, use SPRING5, JAKARTA, DEPENDENCY, CONTAINER, TOMCAT build validation statuses.
- runtime_status is PASS only when runtime validation artifacts indicate PASS; otherwise NOT_RUN.
- phase1_ready for dockerization is true when Phase 1 build_status is PASS.
- phase2_ready for dockerization is true when Phase 2 build_status is PASS.

Action:
- Write the JSON to core/state/migration_state.json.
- Produce the artifact even if empty.
