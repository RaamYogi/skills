# Common Module: Framework Classification

Purpose: Classify migration patterns based on repository_scan output.
Phase: PLAN
Output: outputs/_common/framework_classification.json

Inputs:
- outputs/_common/repo_scan.json
- migration_config.yaml

Constraints:
- Deterministic classification with explicit evidence.
- Do not assume a specific framework; use "unknown" when unsure.
- Sort arrays alphabetically.

Allowed Patterns:
- tomcat8-to-tomcat10
- tomcat9-to-tomcat10
- tomcat-pre10-to-10
- struts-to-spring5
- hibernate-to-spring5
- springx-to-spring5
- spring5-to-spring6
- spring6-to-springboot3
- jsp-view-compatibility
- java8-to-java17
- java11-to-java17
- java9plus-to-java17

Classification Rules:
- Read execution.phase from migration_config.yaml. If empty, treat as "UNKNOWN".
- If tomcat.version starts with "8." and (execution.phase is "SPRING6" or targets.tomcat10_version is not empty), include "tomcat8-to-tomcat10".
- If tomcat.version starts with "9." and (execution.phase is "SPRING6" or targets.tomcat10_version is not empty), include "tomcat9-to-tomcat10".
- If tomcat.version is "unknown" and targets.tomcat10_version is not empty and any pre-10 evidence is true, include "tomcat-pre10-to-10".
  - pre-10 evidence is true when any of the following hold:
    - servlet_api.namespace is "javax"
    - web_xml.schema_version is "2.4" or "2.5" or "3.0" or "3.1" or "4.0"
    - servlet_api.version starts with "2." or "3." or "4."
- If web_framework.name is "struts", include "struts-to-spring5".
- If hibernate.version is not "unknown" and spring.core_version is "unknown" or starts with "2." or "3." or "4." or "5.", include "hibernate-to-spring5".
- If spring.core_version starts with "2." or "3." or "4.", include "springx-to-spring5".
- If spring.core_version starts with "5." and (execution.phase is "SPRING6" or targets.spring6_version is not empty), include "spring5-to-spring6".
- If spring.boot_version starts with "2." and (execution.phase is "SPRING6" or targets.spring_boot3_version is not empty), include "spring6-to-springboot3".
- If view.jsp is "yes" or evidence includes "jsp_file" or "taglib:" or "tiles_config", include "jsp-view-compatibility".
- If java.version starts with "1.7" or "1.8" or is "7" or "8", include "java8-to-java17".
- If java.version starts with "11" or is "11", include "java11-to-java17".
- If java.version is "9" or "10" or "12" or "13" or "14" or "15" or "16", include "java9plus-to-java17".
- If no rule matches, set patterns to ["unknown"].

Phase Guardrails:
- If execution.phase is "SPRING5", do not include any spring5-to-spring6 or spring6-to-springboot3 patterns.
- If execution.phase is "SPRING5", include tomcat* patterns only when targets.tomcat10_version is not empty.

Confidence Rules:
- 1.0 if version evidence is present for the matched pattern.
- 0.7 if only name evidence is present without a version.
- 0.0 if patterns is ["unknown"].

Output JSON Schema:
{
  "patterns": ["<string>"],
  "rationale": [
    {
      "pattern": "<string>",
      "evidence": ["<string>"]
    }
  ],
  "confidence": 0.0
}

Action:
- Write JSON to outputs/_common/framework_classification.json.
- If no patterns are clear, set patterns to ["unknown"], rationale to [], confidence to 0.0.
- Produce the artifact even if empty.
