# Common Module: File Inventory Baseline

Purpose: Capture a deterministic baseline manifest of files in the execution working copy.
Phase: SCAN
Output: outputs/_common/file_manifest_baseline.json

Inputs:
- migration_config.yaml

Constraints:
- Deterministic ordering; no timestamps.
- Only scan execution.source_code_path.
- Exclude build and tool folders: .git, target, build, out, node_modules, .idea, .vscode.
- Do not read or write outside execution.source_code_path.

Output JSON Schema:
{
  "root": "<execution.source_code_path>",
  "excluded": ["<string>"],
  "files": [
    {
      "path": "<relative path>",
      "sha256": "<hex>",
      "size": <number>
    }
  ]
}

Action:
- Walk execution.source_code_path and collect file entries.
- Record path relative to execution.source_code_path.
- Compute sha256 for each file and record size in bytes.
- Sort files lexicographically by path.
- Write JSON to outputs/_common/file_manifest_baseline.json.
- Produce the artifact even if empty.
