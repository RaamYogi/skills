# Common Module: Input Acquisition

Purpose: Acquire the input repository from GitLab, GitHub, or filesystem and capture baseline metadata.
Phase: SCAN
Output: outputs/_common/repo_baseline.md

Inputs:
- migration_config.yaml

Constraints:
- Deterministic output; no timestamps.
- Do not run destructive commands.
- Validate that default_branch exists for Git sources.
- If source_type is filesystem, do not attempt clone.
- If source_type is filesystem and execution.source_code_path differs from input.source_path, copy the full repository to execution.source_code_path before any scans.

Process:
1) Read migration_config.yaml.
2) Read input.source_type and input.source_path.
3) If source_type is "gitlab", select gitlab.repo_url and gitlab.default_branch.
4) If source_type is "github", select github.repo_url and github.default_branch.
5) If source_type is "filesystem", set source_path to input.source_path and skip clone.
6) If source_type is "filesystem" and input.source_path != execution.source_code_path:
   - If execution.source_code_path exists and is not empty, set Validation: FAIL and stop.
   - Else copy the entire source directory to execution.source_code_path.
   - Record the copy action in Notes.
7) If source_type is gitlab or github, clone repository to execution.source_code_path.
8) If source_type is gitlab or github, validate default_branch exists and is checked out.
9) Record baseline SHA for Git sources; use "N/A" for filesystem.

Output Format (fixed headers):
- Source Type:
- Repo URL:
- Default Branch:
- Baseline SHA:
- Source Path:
- Execution Path:
- Validation: <PASS|FAIL>
- Notes:

Action:
- Write output to outputs/_common/repo_baseline.md.
- Produce the artifact even if cloning fails; mark Validation as FAIL and include reason in Notes.
