# Common Module: Global Context

Purpose: Consolidate repository signals and governance constraints into a single deterministic context artifact.
Phase: PLAN
Output: core/context/global_context.json

Inputs:
- migration_config.yaml
- outputs/_common/repo_scan.json
- outputs/_common/java_stack_profile.md
- outputs/_common/framework_classification.json
- outputs/_common/target_version_selection.json
- outputs/_common/spring_config_migration_mapping.md
- core/context/brain_spec.md

Constraints:
- Deterministic output with stable ordering.
- Do not infer beyond evidence; use "unknown" if unclear.
- Include only patterns present in framework_classification.json.
 - Follow the decision rules in core/context/brain_spec.md.

Output JSON Schema:
{
  "context_version": "1.0",
  "phase": "<SPRING5|SPRING6|UNKNOWN>",
  "source": {
    "type": "<filesystem|gitlab|github|unknown>",
    "path": "<string>"
  },
  "detected_patterns": ["<string>"],
  "evidence_summary": ["<string>"],
  "capabilities": {
    "requires_jakarta": "<true|false>",
    "requires_java17": "<true|false>",
    "requires_tomcat10": "<true|false>",
    "requires_spring6": "<true|false>",
    "requires_jspview": "<true|false>",
    "requires_dependency_convergence": "<true|false>",
    "requires_internal_dependency_review": "<true|false>",
    "requires_container_compat": "<true|false>",
    "requires_view_render_checks": "<true|false>",
    "requires_annotation_api": "<true|false>"
  },
  "targets": {
    "spring5_version": "<string>",
    "spring_security5_version": "<string>",
    "hibernate_version": "<string>",
    "spring6_version": "<string>",
    "spring_security6_version": "<string>",
    "spring_boot3_version": "<string>",
    "tomcat10_version": "<string>",
    "java_version": "<string>"
  },
  "decision_rules": ["<string>"],
  "constraints": {
    "enable_apply_phase": "<true|false>",
    "allow_skip_validation": "<true|false>",
    "confidence_threshold": "<number>",
    "stop_on_blocker": "<true|false>",
    "require_approval_for_high_risk": "<true|false>"
  },
  "gating_requirements": [
    {
      "module": "<string>",
      "requires_validation": ["<string>"],
      "allow_skipped_validation": "<true|false>"
    }
  ],
  "known_unknowns": ["<string>"],
  "risk_flags": ["<string>"],
  "notes": "<string>"
}

Action:
- Populate source from migration_config.yaml input and execution paths.
- Read execution.phase from migration_config.yaml; if empty, set phase to "UNKNOWN".
- Apply all phase and gating rules from core/context/brain_spec.md.
- Use framework_classification.json patterns for detected_patterns.
- Summarize evidence using java_stack_profile.md and repo_scan.json.
- Copy targets from migration_config.yaml; use "unknown" when empty.
- Derive capabilities:
  - If phase is "SPRING5", set requires_jakarta to false regardless of detected patterns.
  - Otherwise, requires_jakarta is true if detected_patterns includes spring5-to-spring6 or tomcat9-to-tomcat10 or tomcat8-to-tomcat10 or tomcat-pre10-to-10 or spring6-to-springboot3; or if framework is unknown and javax namespace usage is detected while targets.java_version is "17" or higher.
  - requires_java17 is true if java.version starts with "1.7" or "1.8" or is "7" or "8" or "9" or "10" or "11" or "12" or "13" or "14" or "15" or "16" and targets.java_version is "17" or higher.
  - If phase is "SPRING5", set requires_tomcat10 to false. Otherwise requires_tomcat10 is true if detected_patterns includes tomcat9-to-tomcat10 or tomcat8-to-tomcat10 or tomcat-pre10-to-10.
  - If phase is "SPRING5", set requires_spring6 to false. Otherwise requires_spring6 is true if detected_patterns includes spring5-to-spring6.
  - requires_jspview is true if detected_patterns includes jsp-view-compatibility.
  - requires_dependency_convergence is true if requires_spring6 or requires_jakarta is true, or targets.spring5_version is not empty.
  - requires_internal_dependency_review is true if repo_scan.dependencies.internal is non-empty or repo_scan.dependencies.unclassified is non-empty.
  - requires_container_compat is true if requires_jakarta is true or app_server.name is not "unknown".
  - requires_view_render_checks is true if requires_jspview and requires_jakarta are true.
  - requires_annotation_api is true if annotation_api.usage is not "unknown" and targets.java_version is "17" or higher.
- Populate decision_rules with the rules used above in deterministic order.
- Populate constraints from migration_config.yaml governance/execution.
- Define gating_requirements based on detected patterns, phase, and allow_skip_validation.
- If phase is "SPRING5", exclude JAKARTA and TOMCAT requirements from any SPRING5 gating rules.
- List known_unknowns for any missing targets, missing validation commands, unknown versions, or internal dependencies without compatibility confirmation.
- Write JSON to core/context/global_context.json.
- Produce the artifact even if empty.
