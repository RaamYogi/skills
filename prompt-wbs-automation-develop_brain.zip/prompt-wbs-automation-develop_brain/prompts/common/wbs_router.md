# Common Module: WBS Router

Purpose: Determine execution order for modules based on the generated WBS.
Phase: PLAN
Output: outputs/_global/wbs_execution_plan.json

Inputs:
- outputs/_global/generated_wbs.md
- core/context/global_context.json

Constraints:
- Deterministic ordering; no randomness.
- Only use Low-Level Tasks.
- Preserve phase order within each category: SCAN -> PLAN -> APPLY -> VALIDATE.
- Enforce category precedence for gated upgrades:
  - JAVA, ANNOTATION, JAKARTA, DEPENDENCY, CONTAINER, STRUTS, HIBERNATE, SPRINGX, JSPVIEW must complete before SPRING5.
  - JAKARTA and CONTAINER must complete before TOMCAT.
  - SPRING5 must complete before SPRINGBOOT3.
  - DOCKER5 must complete after SPRINGX/JAVA/STRUTS/HIBERNATE/JSPVIEW.
  - DOCKER6 must complete after SPRING5/JAKARTA/DEPENDENCY/CONTAINER/TOMCAT.
  - COMMITMSG must run after all other categories.  - CONTRACT must always run before API, COMPONENT, FORMS, SERVICE, HTTPCLIENT, ROUTING, WEBUI.
  - SERVICE and HTTPCLIENT must complete before COMPONENT (components depend on hooks/fetch layer).
  - ROUTING must complete before COMPONENT final wiring.
  - FORMS integration tasks must complete before QA.
  - QA must run after all APPLY-phase categories complete.
  - STATE must run after QA.
Output JSON Schema:
{
  "execution_order": [
    {
      "task_id": "<string>",
      "phase": "<SCAN|PLAN|APPLY|VALIDATE>",
      "category": "<string>"
    }
  ]
}

Action:
- Parse Low-Level Tasks from the WBS.
- If global_context.phase is SPRING5, drop any tasks in categories: JAKARTA, TOMCAT, SPRING5, SPRINGBOOT3, DOCKER6.
- If global_context.phase is SPRING6, do not add any new STRUTS or SPRINGX tasks beyond those already in the WBS.
- If global_context.phase is ANGULAR_TO_REACT, apply the Angular-to-React precedence list below.
- Sort categories using the applicable precedence list (not alphabetically). Categories not in the list sort last, alphabetically among themselves.

Precedence list for SPRING5 / SPRING6 (Backend-first):
  CONTRACT, JAVA, ANNOTATION, JAKARTA, DEPENDENCY, CONTAINER, STRUTS, HIBERNATE, SPRINGX,
  JSPVIEW, WEBUI, API, SPRING5, TOMCAT, SPRINGBOOT3, DOCKER5, DOCKER6, QA, STATE, COMMITMSG.

Precedence list for ANGULAR_TO_REACT (Frontend migration):
  CONTRACT, HTTPCLIENT, SERVICE, ROUTING, FORMS, COMPONENT, WEBUI, API, QA, STATE, COMMITMSG.

Precedence list for JSP_TO_REACT (JSP frontend migration):
  CONTRACT, API, WEBUI, ROUTING, FORMS, QA, STATE, COMMITMSG.

- For each category, order tasks by phase order (SCAN < PLAN < APPLY < VALIDATE), then by task_id ascending.
- Write JSON to outputs/_global/wbs_execution_plan.json.
- Produce the artifact even if no tasks are present; use an empty execution_order list.
