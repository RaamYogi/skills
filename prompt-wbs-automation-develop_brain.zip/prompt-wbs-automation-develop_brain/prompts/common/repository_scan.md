# Common Module: Repository Scan

Purpose: Detect language, build tool, framework, packaging, and Java stack indicators.
Phase: SCAN
Output: outputs/_common/repo_scan.json

Inputs:
- migration_config.yaml
- Source repository at execution.source_code_path (working copy).

Constraints:
- Deterministic results only.
- Do not infer beyond direct evidence; use "unknown" if unclear.
- Sort arrays alphabetically.

Output JSON Schema:
{
  "language": ["<string>"],
  "build_tool": ["<string>"],
  "framework": ["<string>"],
  "packaging": ["<string>"],
  "dependencies": {
    "direct": [
      {
        "groupId": "<string>",
        "artifactId": "<string>",
        "version": "<string>",
        "scope": "<string>"
      }
    ],
    "internal": [
      {
        "groupId": "<string>",
        "artifactId": "<string>",
        "version": "<string>",
        "reason": "<string>"
      }
    ],
    "unclassified": [
      {
        "groupId": "<string>",
        "artifactId": "<string>",
        "version": "<string>"
      }
    ]
  },
  "java": {
    "version": "<string>",
    "distribution": "<string>"
  },
  "app_server": {
    "name": "<string>",
    "version": "<string>"
  },
  "web_framework": {
    "name": "<string>",
    "version": "<string>"
  },
  "spring": {
    "core_version": "<string>",
    "boot_version": "<string>"
  },
  "spring_security": {
    "version": "<string>"
  },
  "jackson": {
    "version": "<string>",
    "family": "<unknown|jackson1|jackson2|mixed>"
  },
  "annotation_api": {
    "usage": "<javax|jakarta|unknown>",
    "evidence": ["<string>"]
  },
  "hibernate": {
    "version": "<string>"
  },
  "struts": {
    "version": "<string>"
  },
  "view": {
    "jsp": "<yes|no|unknown>",
    "taglibs": ["<string>"],
    "tiles": "<yes|no|unknown>"
  },
  "web_xml": {
    "schema_version": "<2.4|2.5|3.0|3.1|4.0|5.0|6.0|unknown>"
  },
  "servlet_api": {
    "namespace": "<javax|jakarta|unknown>",
    "version": "<string>",
    "scope": "<provided|compile|unknown>"
  },
  "tomcat": {
    "version": "<string>"
  },
  "jakarta_namespace": "<yes|no|unknown>",
  "evidence": [
    {
      "signal": "<string>",
      "path": "<string>"
    }
  ]
}

Action:
- Write JSON to outputs/_common/repo_scan.json.
- Detect JSP/view evidence:
  - If any *.jsp files exist, set view.jsp to "yes" and record evidence "jsp_file".
  - If any *.tld files exist or JSP taglib URIs include Struts or Tiles, add taglibs entries and record evidence "taglib:<name>".
  - If tiles.xml or tiles*.xml exists, set view.tiles to "yes" and record evidence "tiles_config".
- Detect dependency inventory:
  - Collect direct dependencies from pom.xml (or build files) as groupId, artifactId, version, scope.
  - If dependency_policy.internal_group_prefixes or internal_group_exact is provided in migration_config.yaml, mark matching dependencies as internal and set reason to "groupId match".
  - If policy is empty and dependency_policy.flag_unclassified is true, add all direct dependencies to unclassified and record evidence "internal_policy_missing".
  - If an internal dependency does not map to a local module in a multi-module repo, record evidence "internal_dependency_external_source".
- Detect web.xml schema version:
  - If web.xml references web-app_2_4.xsd, set web_xml.schema_version to "2.4".
  - If web.xml references web-app_2_5.xsd, set web_xml.schema_version to "2.5".
  - If web.xml references web-app_3_0.xsd, set web_xml.schema_version to "3.0".
  - If web.xml references web-app_3_1.xsd, set web_xml.schema_version to "3.1".
  - If web.xml references web-app_4_0.xsd, set web_xml.schema_version to "4.0".
  - If web.xml references web-app_5_0.xsd, set web_xml.schema_version to "5.0".
  - If web.xml references web-app_6_0.xsd, set web_xml.schema_version to "6.0".
  - Else if web.xml exists but no schema is detected, set web_xml.schema_version to "unknown" and record evidence "web_xml_present".
- Detect namespace usage:
  - If any "jakarta." imports or schema URIs are found, set jakarta_namespace to "yes".
  - Else if any "javax." imports or schema URIs are found, set jakarta_namespace to "no".
  - Else set jakarta_namespace to "unknown".
- Detect annotation API usage:
  - If any "javax.annotation." imports are found, set annotation_api.usage to "javax" and record evidence.
  - Else if any "jakarta.annotation." imports are found, set annotation_api.usage to "jakarta" and record evidence.
  - Else set annotation_api.usage to "unknown".
- Detect Jackson usage:
  - If org.codehaus.jackson is present, set jackson.family to "jackson1".
  - If com.fasterxml.jackson is present, set jackson.family to "jackson2".
  - If both are present, set jackson.family to "mixed".
  - Set jackson.version from explicit properties when present; otherwise "unknown".
- Detect servlet API dependencies:
  - If javax.servlet artifacts are present, set servlet_api.namespace to "javax".
  - If jakarta.servlet artifacts are present, set servlet_api.namespace to "jakarta".
  - Capture servlet_api.version and servlet_api.scope when present; otherwise "unknown".
- If no evidence is found, return arrays with a single "unknown" entry, set all scalar fields to "unknown", and an empty evidence array.
- Produce the artifact even if empty.
