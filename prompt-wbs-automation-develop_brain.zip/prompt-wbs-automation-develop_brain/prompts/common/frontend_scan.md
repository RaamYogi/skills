# Common Module: Frontend Technology Scanner

Purpose: Detect the frontend technology type (JSP, Angular, or hybrid) and record version, routing approach, and key metadata.
Phase: SCAN
Output: outputs/_common/frontend_scan.json

Inputs:
- execution.source_code_path (from migration_config.yaml)
- outputs/_common/repo_scan.json

Detection Rules:

JSP Detection:
- Presence of any .jsp file under src/main/webapp/WEB-INF/jsp/ (recursive).
- Presence of WEB-INF/web.xml with DispatcherServlet or JSP-related servlet config.
- Presence of taglib imports (<%@ taglib ... %>) in any .jsp file.
- Presence of Spring MVC view config (mvc-view-config.xml or @EnableWebMvc + ViewResolver bean).
- JSP version: read web-app version attribute in web.xml; default "unknown" if absent.

Angular Detection:
- Presence of angular.json in source root or any subdirectory.
- Presence of @angular/core in package.json dependencies.
- Presence of @NgModule decorator in any .ts file.
- Angular version: read version from package.json "@angular/core" entry; default "unknown" if absent.
- Routing: set to "angular-router" if RouterModule is imported in any .ts file.
- Forms: set to "reactive-forms" if ReactiveFormsModule detected; "template-forms" if FormsModule detected; "both" if both detected.
- HTTP client: set to "HttpClientModule" if HttpClientModule import detected in any .ts file.

Hybrid:
- If both JSP indicators and Angular indicators are detected, set type to "hybrid".
- List detected JSP paths and Angular root path separately.

Output JSON Schema:
{
  "type": "<jsp|angular|hybrid|unknown>",
  "confidence": <float 0.0-1.0>,
  "jsp": {
    "detected": <true|false>,
    "version": "<string|unknown>",
    "view_root": "<relative path or null>",
    "taglib_count": <integer>,
    "jsp_file_count": <integer>
  },
  "angular": {
    "detected": <true|false>,
    "version": "<string|unknown>",
    "root_path": "<relative path or null>",
    "routing": "<angular-router|none|unknown>",
    "forms": "<reactive-forms|template-forms|both|none|unknown>",
    "http_client": "<HttpClientModule|none|unknown>"
  },
  "notes": "<string>"
}

Confidence Rules:
- confidence = 1.0 if only one type detected with at least 3 indicators.
- confidence = 0.8 if only one type detected with 1-2 indicators.
- confidence = 0.9 if hybrid detected with 3+ indicators per type.
- confidence = 0.5 if type is unknown.

Stop Conditions:
- If type is "unknown" and confidence < 0.5, write artifact with type "unknown" then STOP with message: "Frontend type could not be determined. Manual classification required."
- Do not infer beyond file evidence.

Action:
- Scan execution.source_code_path recursively for the indicators above.
- Populate all fields; use "unknown" for any undetected string value and false for undetected booleans.
- Write JSON to outputs/_common/frontend_scan.json.
- Produce the artifact even if all fields are default/unknown.
