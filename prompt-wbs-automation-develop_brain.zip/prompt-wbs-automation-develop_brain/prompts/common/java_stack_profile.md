# Common Module: Java Stack Profile

Purpose: Produce a deterministic Markdown profile for Java stack routing.
Phase: SCAN
Output: outputs/_common/java_stack_profile.md

Inputs:
- outputs/_common/repo_baseline.md
- outputs/_common/repo_scan.json

Constraints:
- Deterministic output with fixed headers and ordering.
- Do not infer beyond direct evidence; use "unknown" if unclear.
- Detected patterns must be from the allowed list only.

Allowed Patterns:
- tomcat8-to-tomcat10
- tomcat9-to-tomcat10
- tomcat-pre10-to-10
- struts-to-spring5
- hibernate-to-spring5
- springx-to-spring5
- spring5-to-spring6
- spring6-to-springboot3
- jsp-view-compatibility
- java8-to-java17

Output Format (fixed headers):
- Source Type:
- Repo Path:
- Java Version:
- Internal Dependencies:
- Dependency Policy:
- App Server:
- Web Framework:
- Spring Core Version:
- Spring Boot Version:
- Spring Security Version:
- Annotation API:
- Hibernate Version:
- Struts Version:
- Tomcat Version:
- Jakarta Namespace:
- View Layer:
- Detected Patterns: <comma-separated list or "none">
- Evidence Summary:

Pattern Detection Rules:
- If tomcat.version starts with "8.", include "tomcat8-to-tomcat10".
- If tomcat.version starts with "9.", include "tomcat9-to-tomcat10".
- If tomcat.version is "unknown" and any pre-10 evidence is true, include "tomcat-pre10-to-10".
  - pre-10 evidence is true when any of the following hold:
    - servlet_api.namespace is "javax"
    - web_xml.schema_version is "2.4" or "2.5" or "3.0" or "3.1" or "4.0"
    - servlet_api.version starts with "2." or "3." or "4."
- If web_framework.name is "struts", include "struts-to-spring5".
- If hibernate.version is not "unknown" and spring.core_version is "unknown" or starts with "2." or "3." or "4." or "5.", include "hibernate-to-spring5".
- If spring.core_version starts with "2." or "3." or "4.", include "springx-to-spring5".
- If spring.core_version starts with "5.", include "spring5-to-spring6".
- If spring.boot_version starts with "2.", include "spring6-to-springboot3".
- If view.jsp is "yes" or view.tiles is "yes" or view.taglibs is non-empty, include "jsp-view-compatibility".
- If java.version starts with "1.7" or "1.8" or is "7" or "8", include "java8-to-java17".

Action:
- For View Layer, output: "jsp=<yes|no|unknown>, tiles=<yes|no|unknown>, taglibs=[...]" derived from repo_scan.json.
- For Annotation API, output: "javax|jakarta|unknown" derived from repo_scan.json annotation_api.usage.
- For Internal Dependencies, output a comma-separated list of dependencies from repo_scan.json dependencies.internal; use "none" when empty.
- For Dependency Policy, output "configured" if dependency_policy prefixes/exact lists are non-empty; else "missing".
- Write the Markdown to outputs/_common/java_stack_profile.md.
- Produce the artifact even if empty.
