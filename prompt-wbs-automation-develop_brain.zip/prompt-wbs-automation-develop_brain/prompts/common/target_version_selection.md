# Common Module: Target Version Selection

Purpose: Determine and confirm target versions for detected upgrade patterns.
Phase: PLAN
Output: outputs/_common/target_version_selection.json

Inputs:
- migration_config.yaml
- outputs/_common/repo_scan.json
- outputs/_common/framework_classification.json

Constraints:
- Deterministic output with stable ordering.
- Do not fetch versions from the internet; use migration_config.yaml targets or mark as "unknown".
- Only include targets relevant to detected patterns.

Target Mapping:
- springx-to-spring5 -> targets.spring5_version, targets.spring_security5_version
- hibernate-to-spring5 -> targets.hibernate_version
- spring5-to-spring6 -> targets.spring6_version, targets.spring_security6_version, targets.java_version
- spring6-to-springboot3 -> targets.spring_boot3_version
- tomcat9-to-tomcat10 -> targets.tomcat10_version
- tomcat8-to-tomcat10 -> targets.tomcat10_version
- tomcat-pre10-to-10 -> targets.tomcat10_version
- java8-to-java17 -> targets.java_version
- java11-to-java17 -> targets.java_version
- java9plus-to-java17 -> targets.java_version

Sanity Checks:
- If both targets.spring5_version and targets.spring6_version are non-empty, set status to MISSING and note the conflict.
- If execution.phase is provided in migration_config.yaml:
  - SPRING5: targets.spring5_version and targets.java_version must be set; targets.spring6_version and targets.tomcat10_version must be empty.
  - SPRING6: targets.spring6_version, targets.tomcat10_version, and targets.java_version must be set; targets.spring5_version must be empty.
  - If phase rules are violated, set status to MISSING and note the conflict.
- If execution.phase is empty or not in [SPRING5, SPRING6], set status to MISSING and note invalid phase.

Output JSON Schema:
{
  "status": "<COMPLETE|MISSING>",
  "required_targets": ["<string>"],
  "provided_targets": {
    "<target_key>": "<value|unknown>"
  },
  "missing_targets": ["<string>"],
  "notes": "<string>"
}

Action:
- If any required target is empty in migration_config.yaml, set status to MISSING and list missing_targets.
- If any sanity check fails, set status to MISSING and describe the conflict in notes.
- If all required targets are present, set status to COMPLETE.
- Write the JSON to outputs/_common/target_version_selection.json.
- Produce the artifact even if empty.
