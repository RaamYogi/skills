# Common Module: File Change Report

Purpose: Compute deterministic file changes by comparing the baseline manifest to current state.
Phase: VALIDATE
Output: outputs/_final/file_change_report.json

Inputs:
- migration_config.yaml
- outputs/_common/file_manifest_baseline.json

Constraints:
- Deterministic ordering; no timestamps.
- Only scan execution.source_code_path.
- Use the same exclude list as file_inventory_baseline.

Output JSON Schema:
{
  "root": "<execution.source_code_path>",
  "baseline": "outputs/_common/file_manifest_baseline.json",
  "summary": {
    "added": <number>,
    "removed": <number>,
    "modified": <number>,
    "unchanged": <number>
  },
  "added": ["<relative path>"],
  "removed": ["<relative path>"],
  "modified": ["<relative path>"]
}

Action:
- Re-scan execution.source_code_path to build a current manifest with the same rules.
- Compare current manifest to baseline by relative path and sha256.
- Populate added, removed, modified lists and summary counts.
- Sort all path lists lexicographically.
- Write JSON to outputs/_final/file_change_report.json.
- Produce the artifact even if empty.
