# Common Module: GitLab Source Preflight

Purpose: Validate GitLab configuration, document the PAT injection pattern, construct the clone command, and produce the repo baseline artifact for a GitLab-sourced migration.
Phase: SCAN
Output: outputs/_common/repo_baseline.md

Inputs:
- migration_config.yaml (gitlab.repo_url, gitlab.default_branch, gitlab.working_branch_prefix, gitlab.pat_env_variable, execution.source_code_path)

---

## PAT Injection Rule (CRITICAL - Prompt-Only Constraint)

Prompt-only execution cannot read operating system environment variables.
The operator MUST substitute the PAT value directly into migration_config.yaml BEFORE invoking the agent.

Required operator action before pasting the single run prompt:
1. Open migration_config.yaml.
2. Locate the field: pat_env_variable: "GITLAB_PAT" (or the value of gitlab.pat_env_variable).
3. Add a sibling field: pat_value: "<your actual PAT token>" directly below pat_env_variable.
4. Save the file.
5. Only then paste the agent run prompt.

The agent reads pat_value from migration_config.yaml. Never store PAT tokens in version-controlled files in production. Treat migration_config.yaml as a local-only, non-committed config during migration runs.

---

## Validation Steps

1. Read gitlab.repo_url.
   - Must be non-empty.
   - Must start with "https://" or "git@".
   - If empty or invalid → STOP: "GitLab repo_url is missing or malformed. Check migration_config.yaml."

2. Read gitlab.default_branch.
   - Must be non-empty.
   - If empty → STOP: "GitLab default_branch is missing."

3. Read pat_value (injected by operator per above rule).
   - If missing → STOP: "pat_value not found in migration_config.yaml. See GitLab PAT Injection Rule."

4. Read execution.source_code_path.
   - Confirm it is set and is a valid absolute path.
   - If path already contains files and is not a clean copy of the target repo → STOP: "execution.source_code_path is non-empty. Manual cleanup required."

---

## Clone Command

Construct the following command using config values and display it for agent execution:

```
git clone --branch <gitlab.default_branch> https://oauth2:<pat_value>@<repo_url_without_scheme> "<execution.source_code_path>"
```

Example (for reference only, do not use literal values):
```
git clone --branch main https://oauth2:glpat-xxxx@gitlab.example.com/group/repo.git "C:/migration/execution/repo"
```

Execute this command via terminal.

---

## Post-Clone Validation

After clone:
1. Verify execution.source_code_path exists and is non-empty.
2. Verify pom.xml or build.gradle exists at the root (Java project indicator).
3. Record the HEAD commit SHA: run `git rev-parse HEAD` in the cloned directory.

---

## Output: outputs/_common/repo_baseline.md

Produce with these exact fields:
```
- Source Type: gitlab
- Repo URL: <gitlab.repo_url>
- Default Branch: <gitlab.default_branch>
- Working Branch Prefix: <gitlab.working_branch_prefix>
- Baseline SHA: <HEAD commit SHA from post-clone step>
- Execution Path: <execution.source_code_path>
- Validation: PASS
- Notes: Cloned from GitLab. PAT was supplied via pat_value field in migration_config.yaml.
```

If any validation step failed, set Validation: FAIL and note the stop reason.

Stop Conditions:
- Missing or malformed repo_url → STOP.
- Missing default_branch → STOP.
- Missing pat_value → STOP.
- Non-empty execution path that is not the target repo → STOP.
