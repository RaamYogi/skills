# Common Module: Spring Config Migration Mapping

Purpose: Produce a deterministic mapping of Spring XML schema updates for Spring 5 upgrades.
Phase: PLAN
Output: outputs/_common/spring_config_migration_mapping.md

Inputs:
- migration_config.yaml
- outputs/_common/repo_scan.json
- outputs/_common/framework_classification.json

Constraints:
- Deterministic output with fixed headers and stable ordering.
- Only include files that reference Spring XML schemas in the repository.
- Do not modify files; this prompt only produces the mapping artifact.

Output Format (fixed headers):
- Scope:
- Mapping Rules:
- Files and Mappings:
- Notes:

Mapping Rules (fixed):
- Replace any `spring-<module>-4.*.xsd` with `spring-<module>.xsd`.
- Replace any `spring-<module>-3.*.xsd` with `spring-<module>.xsd`.

Action:
- Enumerate each Spring XML file and list exact schemaLocation replacements.
- Write the mapping to outputs/_common/spring_config_migration_mapping.md.
- Produce the artifact even if empty.
