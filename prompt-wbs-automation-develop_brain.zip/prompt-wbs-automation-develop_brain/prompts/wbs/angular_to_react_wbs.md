# WBS Module: Angular to React Frontend Migration

Purpose: Generate deterministic WBS tasks for migrating an Angular frontend to a React frontend while preserving the Spring Boot backend API layer.
Phase: PLAN
Output: outputs/_global/generated_wbs.md

Inputs:
- outputs/_common/route_inventory.md
- outputs/_common/frontend_scan.json
- outputs/_common/repo_scan.json
- outputs/_common/java_stack_profile.md
- core/context/global_context.json

Constraints:
- Deterministic ordering.
- Preserve all backend Spring API endpoints unchanged unless new adapters are explicitly required.
- Preserve Angular routing path strings in the React Router equivalents (no URL changes).
- Generate tasks by feature slice, not by technical layer only.
- Angular JSP fallback is not applicable; use Angular component as fallback until React component achieves QA PASS.
- Use phases strictly: SCAN, PLAN, APPLY, VALIDATE.

Required Categories:
- CONTRACT   (shared type/field contracts between Angular and React)
- COMPONENT  (React component implementations)
- SERVICE    (data-fetching hooks replacing Angular services)
- ROUTING    (React Router replacing Angular RouterModule)
- FORMS      (react-hook-form replacing Angular Reactive/Template forms)
- HTTPCLIENT (fetch/axios layer replacing Angular HttpClient)
- STATE      (state management checkpoint and evidence)
- QA         (component and integration parity tests)
- COMMITMSG  (commit message for the migration)

Feature Slice Rules:
- Start with a single low-risk, read-only slice first (e.g., list/details with no form submission).
- Default first slice: the first list/details route found in route_inventory.md.
- Include separate tasks for form validation parity and redirect/navigation parity.

Task Naming Rules:
- High-Level: <CATEGORY>-H<NN>
- Low-Level:  <CATEGORY>-L<NN>_<semantic-slug>
- Semantic slug: lowercase, hyphen-separated, max 5 words derived from task title.
- IDs must be unique and stable.

---

## Minimum Low-Level Tasks

### CONTRACT
- CONTRACT-L01_angular-react-type-contract: Define shared TypeScript interfaces/types mapping Angular model classes to React prop shapes. Map @Input/@Output to props. Map Angular service response types to fetch response types.

### COMPONENT
- COMPONENT-L01_angular-component-prop-shape-plan: For each Angular component in the selected slice, document: @Input bindings → React props; @Output EventEmitters → callback props; local state variables → useState hooks; lifecycle hooks → useEffect equivalents.
- COMPONENT-L02_react-functional-component-impl: Implement each React functional component with hooks. Use React 18 patterns. Preserve template structure and CSS classes from Angular templates. Do not introduce new routing at this step.

### SERVICE
- SERVICE-L01_angular-service-to-react-hook: Convert each Angular @Injectable service that the selected slice depends on into a custom React hook (useXxx). Preserve all HTTP endpoint URLs exactly. Replace Observable/RxJS patterns with async/await + useState/useEffect.

### ROUTING
- ROUTING-L01_angular-routes-to-react-router: Map RouterModule.forRoot and lazy-loaded route definitions to react-router-dom v6 <Routes>/<Route> declarations. Preserve route path strings. Map Angular route guards (CanActivate) to React route wrapper components.

### FORMS
- FORMS-L01_angular-forms-to-react-hook-form: Convert Angular ReactiveFormsModule FormGroup/FormControl/Validators or TemplateDrivenForms to react-hook-form v7 useForm(). Preserve all validation rules (required, minLength, pattern, etc.) and error message strings exactly.

### HTTPCLIENT
- HTTPCLIENT-L01_angular-httpclient-to-fetch-layer: Replace Angular HttpClient calls with a fetch/axios service module. Preserve all API endpoint paths, HTTP methods, request/response shapes, and error handling behavior. Intercepts (HttpInterceptor) must be replaced with axios interceptors or fetch wrappers.

### STATE
- STATE-L01_migration-state-checkpoint: Update core/state/migration_state.json and outputs/_global/module_reports/STATE-L01_report.md with evidence from all APPLY reports.

### QA
- QA-L01_react-component-parity-tests: Run Jest + React Testing Library tests for each migrated component. Verify: render output matches Angular template structure; form validation messages match; API calls are made to the correct endpoints; navigation on submit/cancel matches Angular behavior.

### COMMITMSG
- COMMITMSG-L01_migration-commit-message: Generate commit message for the Angular-to-React migration slice per conventional commits format.

---

## WBS Output Format

Title: Generated WBS (Angular to React)

Sections in fixed order:
1) Summary
2) High-Level Tasks
3) Low-Level Tasks

## Validation Requirements
- Record PASS/FAIL/NOT_RUN/SKIPPED for each QA task.
- Record evidence: Jest test run command, test file path, test count, failure count.
- Angular component remains importable as fallback until QA-L01 is PASS.

Action:
- Read route_inventory.md to identify the first feature slice.
- Read frontend_scan.json to confirm type is "angular" or "hybrid".
- If type is "jsp" or "unknown", do not use this WBS prompt; use jsp_to_react_wbs.md or stop.
- Write outputs/_global/generated_wbs.md.
- Produce the artifact even if empty.
