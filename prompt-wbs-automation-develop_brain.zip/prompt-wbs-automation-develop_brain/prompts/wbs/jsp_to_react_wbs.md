# WBS Module: JSP to React Frontend Migration

Purpose: Generate deterministic WBS tasks for migrating JSP views to a React 18 frontend while keeping the Spring Boot backend fully intact. Every JSP route, form, look-and-feel element, inline/static data, and session/auth flow must have a corresponding task.
Phase: PLAN
Output: outputs/_global/generated_wbs.md

---

## Inputs

- outputs/_common/jsp_route_inventory.md
- outputs/_common/repo_scan.json
- outputs/_common/java_stack_profile.md
- outputs/_common/framework_classification.json
- core/context/global_context.json

---

## Hard Constraints

- Deterministic ordering; no random or optional tasks.
- Backend business logic is NEVER modified. Only `@RestController` adapter endpoints are added.
- All existing `@Controller` JSP mappings remain untouched until VALIDATE passes for the slice.
- Generate tasks by feature slice, not by technical layer.
- Phases strictly: SCAN → PLAN → APPLY → VALIDATE.
- JSP fallback (G-02) stays active until `QA-L01` reports PASS for the slice.
- React app is scaffolded inside the existing Spring Boot project (served from `/react/`).

---

## Required Categories (in execution order)

1. CONTRACT — Extract data shapes from JSP model attributes and JSTL expressions.
2. API — Add REST endpoints alongside existing MVC controllers.
3. WEBUI — Scaffold React app; implement components for every JSP view.
4. FORMS — Migrate form + validation + redirect/navigation parity.
5. COMPAT — Session, auth, error-page, and CSS/look-and-feel compatibility.
6. QA — Parity tests: functional, visual regression, form behaviour.
7. STATE — Checkpoint: record evidence, update migration state.
8. COMMITMSG — Generate structured commit message.

---

## Feature Slice Rules

- Work one slice at a time (default first slice: **Owners Find / List / Details**).
- Do not start a new slice until QA-L01 for the current slice is PASS.
- If the JSP page contains hardcoded/static data (e.g., `<c:forEach>` over a literal list), extract it into a mock fixture before API work begins.

---

## WBS Output Format

Title: Generated WBS — JSP to React Migration
Sections (fixed order):
  1) Summary
  2) High-Level Tasks
  3) Low-Level Tasks

Task ID Rules:
- High-Level : `<CATEGORY>-H<NN>`
- Low-Level  : `<CATEGORY>-L<NN>_<semantic-slug>`
- IDs are unique, stable, and slug-derived from the task title.

---

## Minimum Low-Level Tasks

Instantiate each task below for the current slice (e.g., prefix slug with slice name: `CONTRACT-L01_owners-dto-field-mapping`).
Add any additional tasks discovered from `jsp_route_inventory.md` that are not in the minimum set.

### CONTRACT

- CONTRACT-L01_<slice>-dto-field-mapping
  Phase: PLAN
  Scenario: Inspect every JSP `${model.*}` and `<form:*>` binding. Produce a field-level DTO contract table with Java type, JSP expression, and proposed JSON key. Identify nullable fields and validation constraints.

- CONTRACT-L02_<slice>-jstl-data-mock
  Phase: SCAN
  Scenario: Detect hardcoded/static data embedded in JSTL (`<c:forEach>`, `<c:set>`, scriptlets). Extract to a TypeScript fixture file (`src/mocks/<Entity>Fixtures.ts`) matching the DTO contract from CONTRACT-L01. This fixture is the React data source until the real API is wired.

### API

- API-L01_<slice>-endpoint-plan
  Phase: PLAN
  Scenario: Map every JSP route for the current slice (from `jsp_route_inventory.md`) to a REST endpoint. Define: HTTP method, path, path params, query params, request body schema, response schema, and HTTP error codes. Verify the existing `@Service` methods that will back each endpoint.

- API-L02_<slice>-endpoint-impl
  Phase: APPLY
  Scenario: Implement Spring `@RestController` endpoints. Each method returns `ResponseEntity<DTO>` backed by the existing `@Service` layer. No business logic is duplicated. Add `@CrossOrigin` or configure Spring Security CSRF exemption for `/api/**`. Use Java records for DTOs where Spring Boot version >= 2.5.

### WEBUI

- WEBUI-L01_react-host-scaffold
  Phase: APPLY
  Scenario: Create the React 18 + Vite + TypeScript project inside `src/main/webapp/react-app/`. Configure Vite dev proxy to forward `/api/**` to Spring Boot. Wire React Router v6 with a route for each migrated view. Configure Spring MVC `ResourceHandlerRegistry` to serve `index.html` for `/react/**`. This task runs ONCE for the entire migration, not per slice.

- WEBUI-L02_<slice>-component-impl
  Phase: APPLY
  Scenario: Implement a React component for each JSP view in the current slice. Use `useQuery` (TanStack Query) for data fetching against the endpoints from API-L02. Component props must be typed to match the DTO contract from CONTRACT-L01. Use the mock fixture from CONTRACT-L02 as fallback when `import.meta.env.VITE_USE_MOCKS=true`.

- WEBUI-L03_<slice>-look-feel-parity
  Phase: APPLY
  Scenario: Replicate the visual layout of each JSP page. Map every Bootstrap CSS class and custom stylesheet class to the corresponding React component. Mirror any JSTL-conditional class application (`<c:if test="...">`) as conditional classNames. Match table structures, button placement, pagination, and heading hierarchy exactly. Do NOT redesign; pixel-level parity is required.

### FORMS

- FORMS-L01_<slice>-form-validation-parity
  Phase: APPLY
  Scenario: Implement React Hook Form + Zod schema validation for each form. Mirror every server-side Spring Validation constraint (`@NotBlank`, `@Size`, `@Pattern`, `@Email`, `@Min`, `@Max`) as a Zod rule. POST to the API endpoint; handle `400 { errors: [{field, message}] }` and display inline error messages in the same position as JSP `<form:errors path="...">`. Error message text must be identical.

- FORMS-L02_<slice>-redirect-nav-parity
  Phase: APPLY
  Scenario: Match every JSP redirect and forward (`redirect:/owners/{id}`, `return "ownersList"`) with a `useNavigate()` call. Navigation after successful form submit must land on the same path as the JSP flow. Preserve any query string parameters passed during redirect.

### COMPAT

- COMPAT-L01_session-auth-compat
  Phase: APPLY
  Scenario: Configure React `fetch`/axios calls with `credentials: 'include'` to carry the Spring Security session cookie. Configure CORS in Spring Security to allow the React dev origin. If CSRF protection is active: fetch the CSRF token from `GET /csrf` (Spring Security endpoint) and include it as `X-CSRF-TOKEN` header on all mutating calls. Do NOT rewrite authentication or authorization logic.

- COMPAT-L02_error-page-parity
  Phase: APPLY
  Scenario: Identify existing JSP error pages (`error.jsp`, `403.jsp`, `404.jsp`, `500.jsp`). Implement equivalent React Error Boundary components and React Router error elements for each HTTP error code. API 4xx/5xx responses must render matching error UI with the same user-visible message text.

### QA

- QA-L01_<slice>-functional-parity-tests
  Phase: VALIDATE
  Scenario: Write Vitest + React Testing Library tests for every component in the current slice. Required test cases: (1) empty-state render, (2) data-loaded render using mock fixture, (3) search/filter interaction, (4) form submission — success path, (5) form submission — validation error path, (6) navigation after submit lands on correct path. All tests must pass before the slice is DONE.

- QA-L02_<slice>-visual-regression-check
  Phase: VALIDATE
  Scenario: Side-by-side comparison of each migrated page: JSP version vs React version. Capture screenshots (Playwright or manual) for: (1) list view, (2) detail view, (3) form empty state, (4) form validation error state. Record PASS/FAIL with evidence in `outputs/_validation/visual_regression_<slice>.md`.

### STATE

- STATE-L01_<slice>-migration-state-checkpoint
  Phase: VALIDATE
  Scenario: Update `core/state/migration_state.json` with: completed slice name, list of modified files, QA-L01 result, QA-L02 result, timestamp, and whether JSP fallback was removed for this slice. Set `fallback_active: false` only when both QA tasks are PASS.

### COMMITMSG

- COMMITMSG-L01_<slice>-migration-commit-message
  Phase: APPLY
  Scenario: Generate a conventional commit message summarising all changes for the current slice. Format: `feat(jsp-to-react): migrate <slice> to React 18`. Body must list: added files, changed files, and QA validation result.

---

## Action

1. Read `jsp_route_inventory.md` and `repo_scan.json`.
2. Instantiate each Minimum Low-Level Task replacing `<slice>` with the actual slice name (e.g., `owners`).
3. Add any additional tasks discovered from the route inventory that are not in the minimum set.
4. Write the full WBS to `outputs/_global/generated_wbs.md` in the fixed-section format.
5. Produce the artifact even if input files are empty (use placeholder values and flag HIGH risk).

---

## Structured Skill-Pack Mapping (mandatory)

In addition to regular WBS output, maintain a deterministic mapping to:

`outputs/_global/frontend_to_react/skills/`

Required sequence:

- analysis/01_baseline_analysis.md
- analysis/02_component_mapping.md
- analysis/03_api_dependency_scan.md
- analysis/04_state_management_analysis.md
- analysis/05_migration_planning.md
- migration/06_rest_api_creation.md
- migration/07_cors_configuration.md
- migration/08_react_setup.md
- migration/09_component_migration.md
- migration/10_routing_migration.md
- migration/11_state_management.md
- migration/12_integration_bridge.md
- validation/13_testing_setup.md
- validation/14_build_integration.md
- validation/15_deployment_validation.md

Each generated low-level task must reference at least one of the above files in its implementation notes.
If mapping cannot be established for any task, emit BLOCKER and stop planning.
If any referenced structured skill filename differs from the canonical fixed names, emit BLOCKER and stop planning.
