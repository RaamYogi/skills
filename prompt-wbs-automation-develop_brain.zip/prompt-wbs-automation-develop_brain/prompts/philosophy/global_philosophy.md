# Global Philosophy

Purpose: Define the non-negotiable operating philosophy for the Migration Automation Operating System.
Phase: PLAN
Output: outputs/_global/philosophy_ack.md

Core System Constraints:
- Prompt-only execution; no hidden automation logic.
- Model-agnostic prompts with no model-specific dependencies.
- Deterministic outputs with fixed ordering and stable keys.
- Structured outputs only (JSON or fixed-header Markdown).

Determinism Rules:
- Do not use timestamps, random values, or environment-specific data.
- Sort lists alphabetically unless an explicit order is required.
- Use stable keys and fixed section ordering.

RACI Model:
- Responsible: Automation Operator (executes prompts, produces artifacts).
- Accountable: Migration Owner (approves high risk and blockers).
- Consulted: Subject Matter Experts (provide domain constraints).
- Informed: Stakeholders (receive reports and MR summary).

Escalation Model:
- Level 0: Continue with documented assumptions.
- Level 1: Pause module and request human approval.
- Level 2: Stop all execution and mark BLOCKER.

Error Classification:
- BLOCKER: Unsafe to proceed without explicit approval.
- HIGH: Significant risk; requires approval if governance mandates.
- MEDIUM: Noticeable risk; proceed with documented mitigation.
- LOW: Minor risk; proceed and document.

Error Response Template (deterministic Markdown):
- Title: [ERROR] <classification> - <short label>
- Context: <module name>
- Evidence: <facts only>
- Impact: <what breaks or changes>
- Mitigation: <step(s) to reduce risk>
- Escalation: <Level 0|1|2>
- Decision Needed: <yes/no>

Success Criteria:
- All required artifacts produced with correct paths.
- No phase mixing; scan, plan, apply, validate are distinct.
- All risk classifications recorded using allowed labels.
- MR summary generated at outputs/_final/merge_request_description.md.

Artifact Contract:
- Every prompt must produce exactly one artifact file, even if empty.
- Artifact format is deterministic with explicit headers and stable ordering.
- Artifact files must live under outputs/.

Rollback Discipline:
- Plan rollback before any APPLY action.
- Rollback must be explicit, reversible, and documented in the MR summary.
- If rollback is not possible, classify risk as HIGH or BLOCKER.

Action:
- Acknowledge this philosophy by writing a short confirmation with the above sections referenced.
- Write output to outputs/_global/philosophy_ack.md.
