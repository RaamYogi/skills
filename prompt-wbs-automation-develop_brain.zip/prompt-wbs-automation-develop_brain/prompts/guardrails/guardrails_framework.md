# Guardrails Framework

Purpose: Define hard constraints for safe, deterministic execution.
Phase: PLAN
Output: outputs/_global/guardrails_ack.md

Rules:
- No destructive commands.
- No secret exposure (redact tokens, passwords, and keys).
- No behavior changes unless explicitly approved.
- Output-first model: always write the artifact before any optional narrative.
- Deterministic structured outputs only (JSON or fixed-header Markdown).
- Prompt-only execution; do not introduce hidden automation logic.
- Model-agnostic instructions; avoid model-specific features.
- Human-in-loop gates for HIGH and BLOCKER risks.
- Stop when risk threshold is exceeded or governance requires.
- Validation may be skipped only if execution.allow_skip_validation is true; record HIGH risk and require approval when require_approval_for_high_risk is true.

Risk Threshold Stopping Rules:
- If any BLOCKER is detected, stop immediately.
- If any HIGH risk is detected and require_approval_for_high_risk is true, stop and request approval.
- If confidence is below execution.confidence_threshold, stop and request clarification.

Action:
- Confirm compliance with each rule and note any constraints.
- Write output to outputs/_global/guardrails_ack.md.
