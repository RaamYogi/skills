# Orchestration: Execution Trace

Purpose: Write and update a deterministic execution trace after each phase and each skill execution. Provides resume-from-failure capability and a machine-readable audit log.
Phase: ALL (written after each major step)
Output: core/orchestrator/execution_trace.json

Inputs:
- outputs/_global/skill_index.json
- outputs/_global/module_reports/*.md
- core/state/migration_state.json

---

## When to Write

Write (or overwrite) core/orchestrator/execution_trace.json at these points:
1. After PLAN phase completes (all skills generated).
2. After each APPLY skill completes (update completed_skills and last_completed_skill).
3. After each VALIDATE skill completes.
4. After CONSOLIDATE phase completes.

---

## Output JSON Schema

```json
{
  "run_id": "<config_derived_slug>_<phase>",
  "source_path": "<execution.source_code_path>",
  "framework_root": "<framework repo root>",
  "phase_status": {
    "SCAN":        "<COMPLETE|IN_PROGRESS|NOT_RUN|FAILED>",
    "PLAN":        "<COMPLETE|IN_PROGRESS|NOT_RUN|FAILED>",
    "APPLY":       "<COMPLETE|IN_PROGRESS|NOT_RUN|FAILED>",
    "VALIDATE":    "<COMPLETE|IN_PROGRESS|NOT_RUN|FAILED>",
    "CONSOLIDATE": "<COMPLETE|IN_PROGRESS|NOT_RUN|FAILED>"
  },
  "execution_order": ["<task_id>", "..."],
  "completed_skills": ["<task_id>", "..."],
  "failed_skills": ["<task_id>", "..."],
  "skipped_skills": ["<task_id>", "..."],
  "last_completed_skill": "<task_id or null>",
  "resume_from": "<task_id or null>",
  "blocker_detected": <true|false>,
  "blocker_reason": "<string or null>"
}
```

---

## run_id Derivation Rules

- Take the last path segment of execution.source_code_path (e.g., "spring-mvc-jsp-petclinic-master").
- Append "_" and the current phase name (e.g., "APPLY").
- Result: "spring-mvc-jsp-petclinic-master_APPLY".
- Do not use timestamps (determinism rule).

---

## resume_from Rules

- Set resume_from to null when all skills in execution_order are in completed_skills, failed_skills, or skipped_skills.
- Set resume_from to the first task_id in execution_order that is not yet in completed_skills, failed_skills, or skipped_skills.
- If blocker_detected is true, resume_from must be set to the blocked task_id.

---

## Reading for Resume

When the agent starts a new session and finds an existing execution_trace.json:
1. Read resume_from.
2. If not null, skip all skills that appear before resume_from in execution_order.
3. Announce: "Resuming from skill <resume_from>. Skipping previously completed skills: [list]."
4. If blocker_detected is true, require operator confirmation before proceeding past the blocker.

---

## Stop Conditions

- If blocker_detected is true and operator has not explicitly confirmed continuation → STOP.
- Do not overwrite execution_trace.json if the file is locked (write on a best-effort basis).

Action:
- Read skill_index.json for execution_order.
- Read module_reports to determine completed/failed/skipped status.
- Write or update core/orchestrator/execution_trace.json.
- Produce the artifact even if all statuses are NOT_RUN.
