# Orchestration: MR Consolidation

Purpose: Produce a single deterministic Merge Request summary.
Phase: PLAN
Output: outputs/_final/merge_request_description.md

Inputs:
- outputs/_global/module_reports/*.md
- outputs/_global/global_orchestration_report.md
- outputs/_common/*.json
- outputs/_final/file_change_report.json

Responsibilities:
- Aggregate module reports.
- List files changed from file_change_report.json; if missing, set to "unknown".
- Summarize risk and validation results.
- Include rollback plan.

MR Description Format (fixed headers):
- Title:
- Summary:
- Files Changed:
- Change Log:
- Risks:
- Validation:
- Rollback Plan:
- Approvals Needed:

Action:
- Write MR description to outputs/_final/merge_request_description.md.
- Produce the artifact even if empty.
