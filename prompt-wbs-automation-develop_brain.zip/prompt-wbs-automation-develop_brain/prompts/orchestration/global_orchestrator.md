# Orchestration: Global Orchestrator

Purpose: Run the full Phase 0 bootstrap flow deterministically.
Phase: PLAN
Output: outputs/_global/global_orchestration_report.md

Inputs:
- migration_config.yaml
- prompts/philosophy/global_philosophy.md
- prompts/guardrails/guardrails_framework.md
- prompts/common/*.md
- prompts/orchestration/*.md
- prompts/orchestration/frontend_to_react_skill_pack.md

Responsibilities:
- Read migration_config.yaml.
- Run philosophy and guardrails prompts first.
- Run common modules in order: git_clone, file_inventory_baseline, repository_scan, java_stack_profile, framework_classification, target_version_selection, spring_config_migration_mapping, global_context, wbs_generator, wbs_router, state_checkpoint.
- Ensure input acquisition produces a working copy at execution.source_code_path before any scans or plans.
- Generate skills for each Low-Level Task.
- Generate a structured frontend migration skill pack using `prompts/orchestration/frontend_to_react_skill_pack.md`.
- Run module orchestrators by execution plan.
- Consolidate outputs and prepare MR summary.
- Generate a deterministic HTML report from all outputs.
- Enforce gated upgrades:
  - Run SPRING5 only if STRUTS, HIBERNATE, SPRINGX, JSPVIEW, JAVA, ANNOTATION, JAKARTA, DEPENDENCY, and CONTAINER modules report Validation PASS when present. If execution.allow_skip_validation is true, Validation SKIPPED is acceptable with HIGH risk noted.
  - Run TOMCAT only if JAKARTA and CONTAINER report Validation PASS when present. If execution.allow_skip_validation is true, Validation SKIPPED is acceptable with HIGH risk noted.
  - Run SPRINGBOOT3 only if SPRING5 reports Validation PASS when present. If execution.allow_skip_validation is true, Validation SKIPPED is acceptable with HIGH risk noted.
- If target_version_selection status is MISSING, stop and record missing targets in the global report.
- If the structured skill pack manifest is missing or incomplete, stop and record BLOCKER in the global report.
- After module orchestration, run file_change_report, then MR consolidation, then html_report_generator, then run state_checkpoint again to update migration_state.json.

Determinism Rules:
- Fixed module order as listed above.
- No timestamps or randomness.
- Stop on BLOCKER or low confidence.
- If gating conditions are not met, stop and record status in the global report.
- Do not start APPLY if any mandatory skill file is missing required schema headers from the structured skill pack contract.

Global Report Format (fixed headers):
- Status:
- Modules Run:
- Blockers:
- Artifacts Produced: <list of paths>
- Notes:

Action:
- Write report to outputs/_global/global_orchestration_report.md.
- Produce the artifact even if empty.
