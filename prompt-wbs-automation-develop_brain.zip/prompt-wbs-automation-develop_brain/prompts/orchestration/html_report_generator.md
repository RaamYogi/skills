# Orchestration: HTML Report Generator

Purpose: Produce a deterministic static HTML report summarizing the full migration execution.
Phase: VALIDATE
Output: outputs/_final/migration_report.html

Inputs:
- outputs/_global/global_orchestration_report.md
- outputs/_global/module_reports/*.md
- outputs/_final/merge_request_description.md
- outputs/_final/commit_message.md (if present)
- outputs/_final/file_change_report.json
- outputs/_common/repo_baseline.md
- outputs/_common/repo_scan.json
- outputs/_common/framework_classification.json
- outputs/_common/target_version_selection.json
- core/context/global_context.json
- core/state/migration_state.json

Constraints:
- Deterministic output with fixed section ordering and static styling.
- No timestamps or dynamic values.
- Do not infer beyond artifacts; use "unknown" when missing.

HTML Structure (fixed sections in this order):
1) Title and Scope
2) Input and Execution Paths
3) Detected Patterns and Targets
4) Module Execution Summary (table)
5) Validation Summary (build/runtime)
6) Risks and Blockers
7) Artifacts Produced (list)
8) Files Changed (from file_change_report.json)
9) Rollback Plan (from MR summary)
10) Commit Message (if present)

Styling:
- Embed a small, fixed CSS block in the <head>.
- Use simple tables and lists; no external assets.

Action:
- Aggregate content from the input artifacts.
- Write HTML to outputs/_final/migration_report.html.
- Produce the artifact even if empty; use "unknown" or "none" as needed.
