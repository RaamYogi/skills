# Orchestration: Frontend-to-React Skill Pack Contract

Purpose: Enforce a deterministic, structured, implementation-grade skill pack for JSP Spring Boot to React migration.
Phase: PLAN
Output: outputs/_global/frontend_to_react/skill_pack_manifest.md

## Required Directory Layout (fixed)

outputs/_global/frontend_to_react/
├── config/
│   └── repository.properties
├── guardrails/
│   └── COPILOT_SAFETY.md
├── migration/
│   ├── MIGRATION_CONTEXT.md
│   ├── ROLLBACK_STRATEGY.md
│   └── TARGET_ARCHITECTURE.md
├── skills/
│   ├── analysis/
│   │   ├── 01_baseline_analysis.md
│   │   ├── 02_component_mapping.md
│   │   ├── 03_api_dependency_scan.md
│   │   ├── 04_state_management_analysis.md
│   │   └── 05_migration_planning.md
│   ├── migration/
│   │   ├── 06_rest_api_creation.md
│   │   ├── 07_cors_configuration.md
│   │   ├── 08_react_setup.md
│   │   ├── 09_component_migration.md
│   │   ├── 10_routing_migration.md
│   │   ├── 11_state_management.md
│   │   └── 12_integration_bridge.md
│   ├── validation/
│   │   ├── 13_testing_setup.md
│   │   ├── 14_build_integration.md
│   │   └── 15_deployment_validation.md
│   ├── OVERVIEW.md
│   ├── PROMPT_LIBRARY.md
│   └── react_skill_execution_order.md

## Skill Naming Rules (non-negotiable)

- File names MUST be exactly the fixed names in this contract.
- Use two-digit numeric prefixes (`01` ... `15`) and snake_case names only.
- Do not append slice names, category IDs, timestamps, or suffixes.
- Forbidden examples:
	- `API-L02_owners-endpoint-impl_skill.md`
	- `09_component_migration_owners.md`
	- `13_testing_setup_v2.md`
- If a generated skill name does not match exactly, treat as BLOCKER and stop.

## Mandatory Skill File Schema (all 01-15)

Each file must include these headers in order:
1. Objective
2. Source Evidence
3. Preconditions
4. Files to Create/Modify
5. Exact Code Changes (copy-paste ready)
6. Commands to Run
7. Verification Checklist
8. Failure Handling
9. Rollback
10. Output Artifact(s)

## Hard Quality Rules

- No placeholder-only instructions (forbidden: "implement component", "add controller", "update config" without concrete code).
- Every APPLY skill must contain at least one concrete code block and one executable command.
- Field names/types must come from DTO contract artifacts; never from generic examples.
- Keep existing JSP controllers and JSP views intact until validation gate pass criteria are met.
- If required evidence is missing, mark BLOCKER and stop.

## Action

1. Generate the directory tree and all files listed above under `outputs/_global/frontend_to_react/`.
2. Populate files from existing artifacts (`repo_scan`, `jsp_route_inventory`, `global_context`, WBS, skill files).
3. Write `outputs/_global/frontend_to_react/skill_pack_manifest.md` listing all generated files and completion status.
4. Produce artifacts even when partial, but mark missing mandatory content as BLOCKER.
