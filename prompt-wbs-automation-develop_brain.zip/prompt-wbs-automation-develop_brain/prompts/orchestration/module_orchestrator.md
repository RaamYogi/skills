# Orchestration: Module Orchestrator

Purpose: Execute skills for one module in a deterministic sequence.
Phase: PLAN
Output: outputs/_global/module_reports/<module_id>_report.md

Inputs:
- outputs/_global/generated_wbs.md
- outputs/_global/wbs_execution_plan.json
- outputs/_global/generated_skills/<task_id>_skill.md
- migration_config.yaml

Responsibilities:
- Read generated WBS and execution plan.
- Generate skill prompts per Low-Level Task if missing.
- Execute skills sequentially in plan order.
- Stop on BLOCKER.
- Update state file at core/state/module_state.json.
- Write module_report.md.
- Use category as module_id unless explicitly overridden.
- Derive Validation status from VALIDATE task outputs.
- Enforce validation sequencing:
  - Run build validation tasks before any runtime, route, or JSP rendering validations.
  - If build validation is not PASS, mark runtime/route/JSP validations as SKIPPED with reason "build validation not PASS" and do not attempt runtime commands.
  - If build validation is PASS, attempt runtime validations; if commands are missing, mark NOT_RUN with reason "commands not provided".
- If execution.enable_apply_phase is false, skip APPLY tasks and write their artifacts with Status: SKIPPED.
- If validation commands are missing:
  - If build_tool includes "maven", run: mvn clean install -DskipTests in the repo root. If settings.xml exists at repo root, run: mvn clean install -DskipTests -s settings.xml. Record the command and output in the VALIDATE artifact Evidence.
  - Else if execution.allow_skip_validation is true, write VALIDATE artifacts with Validation: SKIPPED and Evidence: allow_skip_validation, mark HIGH risk, and continue.
  - Else write VALIDATE artifacts with Validation: NOT_RUN and Evidence: commands not provided, mark BLOCKER, and stop.
- Before any APPLY task, verify the most recent PLAN artifact contains all required fixed headers and that Target Versions are not "unknown". If not, write the APPLY artifact with Status: BLOCKED and Reason, mark BLOCKER, and stop.
- If the corresponding PLAN task title or description includes "config" or "configuration", verify the PLAN artifact includes a non-empty Config Change List. If missing or "<unknown>", block APPLY as above.
- Before any APPLY task, verify the corresponding structured skill file (from `outputs/_global/frontend_to_react/skills/**`) contains all mandatory schema headers. If any header is missing, mark APPLY as BLOCKED and stop.
- If a skill contains placeholder-only instructions without concrete file paths, code blocks, and commands, mark APPLY as BLOCKED and stop.

Determinism Rules:
- Use execution_order as the single source of truth.
- Do not skip tasks unless explicitly marked blocked.
- Stable ordering; no timestamps.
- If a VALIDATE task fails, mark module as BLOCKED and stop further tasks.

State Update Format (JSON):
{
  "module_id": "<string>",
  "status": "<PENDING|IN_PROGRESS|BLOCKED|DONE>",
  "last_task_id": "<string>",
  "notes": "<string>"
}

Module Report Format (fixed headers):
- Module ID:
- Status:
- Tasks Executed: <comma-separated task IDs>
- Blockers:
- Validation: <PASS|FAIL|NOT_RUN|SKIPPED>
- Validation Evidence:
- Artifacts Produced: <list of paths>
- Notes:

Action:
- Write module report to outputs/_global/module_reports/<module_id>_report.md.
- Produce the artifact even if empty.
