# Orchestration: Skill Generator — JSP to React

Purpose: Convert one Low-Level Task from the WBS into a rich, deterministic, code-bearing skill prompt.
Phase: PLAN
Output: outputs/_global/generated_skills/<CATEGORY>-L<NN>_<semantic-slug>_skill.md

Filename convention:
- Pattern: `<CATEGORY>-<LEVEL><NN>_<semantic-slug>_skill.md`
- CATEGORY and LEVEL come directly from task_id (e.g., API-L02).
- semantic-slug: lowercase, hyphen-separated, maximum 5 words derived from the task title.
  Example: task "Owners endpoint implementation" → slug `owners-endpoint-impl`
- Never use the raw task_id alone as the filename.

Inputs:
- One Low-Level Task entry from outputs/_global/generated_wbs.md

---

## STRUCTURED SKILL PACK MODE (MANDATORY FOR JSP_TO_REACT)

When `global_context.phase = JSP_TO_REACT`, generation MUST also maintain:

`outputs/_global/frontend_to_react/skills/`

Required files:
- `analysis/01_baseline_analysis.md`
- `analysis/02_component_mapping.md`
- `analysis/03_api_dependency_scan.md`
- `analysis/04_state_management_analysis.md`
- `analysis/05_migration_planning.md`
- `migration/06_rest_api_creation.md`
- `migration/07_cors_configuration.md`
- `migration/08_react_setup.md`
- `migration/09_component_migration.md`
- `migration/10_routing_migration.md`
- `migration/11_state_management.md`
- `migration/12_integration_bridge.md`
- `validation/13_testing_setup.md`
- `validation/14_build_integration.md`
- `validation/15_deployment_validation.md`
- `OVERVIEW.md`
- `PROMPT_LIBRARY.md`
- `react_skill_execution_order.md`

Canonical naming policy:
- These names are mandatory and exact.
- The structured skill-pack filenames above are the primary skill outputs for JSP_TO_REACT.
- `outputs/_global/generated_skills/<CATEGORY>-...` may exist only as compatibility mirrors, not as canonical names.
- If canonical file names are not generated exactly, emit BLOCKER and stop.

Each of the 01-15 skill files MUST include these exact headers in order:
1) Objective
2) Source Evidence
3) Preconditions
4) Files to Create/Modify
5) Exact Code Changes (copy-paste ready)
6) Commands to Run
7) Verification Checklist
8) Failure Handling
9) Rollback
10) Output Artifact(s)

---

## NON-NEGOTIABLE QUALITY GATES

- Never use placeholder-only language (forbidden examples: "implement this", "add endpoint", "configure CORS" without concrete code and file paths).
- Every APPLY skill must include at least:
  - one concrete code block with real class/variable names from scan artifacts,
  - one executable command,
  - one verification command/check.
- DTO and field names must come from `outputs/_common/dto_contract_<slice>.md` or model class evidence; do not invent sample fields.
- If entity fields in templates do not match source model evidence, mark BLOCKER and stop.
- Do not output static placeholder HTML as React host completion proof.
- If required evidence is missing, emit BLOCKER and stop.
- If a skill file is generated with non-canonical name (wrong prefix/order/name), emit BLOCKER and stop.

---

## ARCHETYPE DETECTION

Before generating the skill body, inspect the task_id slug and title.
Match against the table below (first match wins). The matched Archetype
determines the template and minimum word count.

| Keyword(s) in task slug / title                      | Archetype          | Min Words |
|------------------------------------------------------|--------------------|----------|
| `endpoint-impl` / `RestController` / `@Controller`  | REST_API           | 400       |
| `react-host-scaffold` / `vite` / `scaffold`          | REACT_SCAFFOLD     | 400       |
| `look-feel` / `css` / `bootstrap` / `style`          | STYLE_PARITY       | 300       |
| `form-validation` / `form-nav` / `hook-form` / `zod` | FORM_VALIDATION    | 400       |
| `jstl-data-mock` / `mock` / `fixture`                | DATA_MOCK          | 300       |
| `functional-parity-tests` / `vitest` / `rtl`         | TEST_VALIDATION    | 400       |
| `session-auth` / `csrf` / `cors` / `cookie`          | SESSION_COMPAT     | 300       |
| `dto-field-mapping` / `contract` / `dto`             | DTO_CONTRACT       | 300       |
| `error-page` / `error-boundary` / `404` / `500`      | ERROR_PARITY       | 300       |
| `commit-message` / `commitmsg`                       | COMMIT_MSG         | 150       |
| _(no match)_                                         | GENERIC            | 150       |

---

## ARCHETYPE TEMPLATES

For each Archetype, the generated skill file MUST include ALL of the following sections in this order:

### Common Fields (all Archetypes)

```
id:               <task_id>
type:             <SCAN|PLAN|APPLY|VALIDATE>
archetype:        <ARCHETYPE_NAME>
produces_diff:    <true|false>
stops_on_blocker: true
objective:        <one sentence — what this skill achieves>
scope:            <which files / packages are touched>
output_path:      outputs/_global/generated_skills/<filename>
risk_behavior:    <BLOCKER|HIGH|MEDIUM|LOW> — <reason>
stop_conditions:  Confidence < 0.70 → STOP. Any BLOCKER flag → STOP. Log to outputs/_global/blockers.md.
```

---

### REST_API Template

Use when: `endpoint-impl`

**Context**
- The existing JSP `@Controller` for this route must remain untouched.
- Add a new `@RestController` class (e.g., `OwnersApiController`) in the same package or a `.api` sub-package.
- The new controller delegates to the existing `@Service` — no business logic duplication.

**Step-by-Step**

1. Identify the `@Service` method(s) used by the existing JSP controller for this route.
2. Create a Java record DTO matching the field contract from `CONTRACT-L01`:
```java
// Example — replace with actual fields from contract
public record OwnerResponse(Long id, String firstName, String lastName, String address, String city, String telephone) {}
```
3. Create the `@RestController`:
```java
@RestController
@RequestMapping("/api/owners")
@CrossOrigin(origins = "${react.app.origin:http://localhost:5173}")
public class OwnersApiController {

    private final OwnerService ownerService;

    public OwnersApiController(OwnerService ownerService) {
        this.ownerService = ownerService;
    }

    @GetMapping
    public ResponseEntity<List<OwnerResponse>> findOwners(
            @RequestParam(required = false) String lastName) {
        var owners = ownerService.findOwnerByLastName(lastName == null ? "" : lastName);
        if (owners.isEmpty()) return ResponseEntity.noContent().build();
        return ResponseEntity.ok(owners.stream().map(this::toResponse).toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<OwnerResponse> getOwner(@PathVariable Long id) {
        return ResponseEntity.ok(toResponse(ownerService.findOwnerById(id)));
    }

    private OwnerResponse toResponse(Owner o) {
        return new OwnerResponse(o.getId(), o.getFirstName(), o.getLastName(),
                o.getAddress(), o.getCity(), o.getTelephone());
    }
}
```
4. If Spring Security is present: add `/api/**` to the CSRF exclusion list or configure `permitAll` for GET endpoints. Record the config change in `Changes:`.
5. Verify with: `curl -s http://localhost:8080/api/owners?lastName=Davis | jq .`

**Verification**
- HTTP 200 with JSON array when owners exist.
- HTTP 204 when no results.
- HTTP 404 when ID not found.
- Existing JSP route `/owners/find` still returns HTML (not broken).

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - src/main/java/.../api/<Entity>ApiController.java (ADDED)
  - src/main/java/.../api/<Entity>Response.java (ADDED if record is a separate file)
  - src/main/resources/spring/mvc-core-config.xml or SecurityConfig.java (MODIFIED for CORS/CSRF)

---

### REACT_SCAFFOLD Template

Use when: `react-host-scaffold`

**Context**
- This task runs ONCE for the whole migration. Do not repeat per slice.
- The React app lives at `src/main/webapp/react-app/` and is built by `npm run build` into `src/main/webapp/react-app/dist/`.
- Spring Boot serves `/react/**` → `dist/index.html`.

**Step-by-Step**

1. Scaffold the Vite project:
```bash
cd src/main/webapp
npm create vite@latest react-app -- --template react-ts
cd react-app
npm install react-router-dom@6 @tanstack/react-query axios
```
2. Create `vite.config.ts`:
```ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/react/',
  server: {
    proxy: {
      '/api': { target: 'http://localhost:8080', changeOrigin: true },
      '/csrf': { target: 'http://localhost:8080', changeOrigin: true }
    }
  },
  build: { outDir: 'dist' }
})
```
3. Create `src/App.tsx` with React Router:
```tsx
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { QueryClientProvider, QueryClient } from '@tanstack/react-query'

const queryClient = new QueryClient()

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter basename="/react">
        <Routes>
          {/* Add slice routes here as they are implemented */}
          <Route path="/owners" element={<div>Owners placeholder</div>} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}
```
4. Add a Spring MVC resource handler in `WebMvcConfigurer` or `mvc-core-config.xml`:
```java
registry.addResourceHandler("/react/**")
        .addResourceLocations("classpath:/static/react-app/dist/");
// Also add a catch-all for React Router deep links:
// GET /react/{*path} → serve index.html
```
5. Add `npm run build` to the Maven lifecycle via `frontend-maven-plugin` (optional; record if added).

**Verification**
- `http://localhost:8080/react/` loads the React app in the browser.
- `/api/owners` returns JSON (proxy works in dev mode).
- Existing JSP routes are unaffected.

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - src/main/webapp/react-app/ (DIRECTORY ADDED)
  - src/main/resources/spring/mvc-core-config.xml or WebConfig.java (MODIFIED)

---

### STYLE_PARITY Template

Use when: `look-feel`, `css`, `bootstrap`

**Context**
- Do not redesign. The React output must be visually identical to the JSP page.
- Existing Bootstrap version: read from `pom.xml` / `wro.xml` / `webjars` dependency.

**Step-by-Step**

1. Record the Bootstrap version in use (e.g., Bootstrap 3.4 vs 5.x) — different APIs for grid, form classes.
2. Build a class-mapping table:
   | JSP element / class | React component | Notes |
   |---|---|---|
   | `<div class="container">` | `<div className="container">` | direct port |
   | `<c:if test="${empty owners}">` | `{owners.length === 0 && ...}` | conditional render |
   | `<table class="table table-striped">` | `<table className="table table-striped">` | direct port |
3. Apply the same Bootstrap CSS link in `index.html` or import the same `petclinic.css` file.
4. For any JSTL conditional class (`<c:if test="..."> class="active" </c:if>`), implement as:
```tsx
<li className={isActive ? 'active' : ''}>...</li>
```
5. Record all CSS files copied to `src/main/webapp/react-app/public/` in `Changes:`.

**Verification**
- Screenshot comparison: JSP page vs React page at the same viewport (1280×800).
- Table column count, button placement, form label alignment must match exactly.

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - src/main/webapp/react-app/src/components/<Component>.tsx (MODIFIED)
  - src/main/webapp/react-app/public/<stylesheet>.css (COPIED)

---

### FORM_VALIDATION Template

Use when: `form-validation`, `form-nav`, `hook-form`, `zod`

**Context**
- React Hook Form + Zod replaces Spring MVC `@Valid` + `BindingResult`.
- The API endpoint (from API-L02) must return `400 { errors: [{field: string, message: string}] }` for validation failures.

**Step-by-Step**

1. Install dependencies:
```bash
npm install react-hook-form zod @hookform/resolvers
```
2. Mirror every server-side constraint as a Zod rule:
```ts
import { z } from 'zod'
const ownerSchema = z.object({
  firstName:  z.string().min(1, 'First name is required').max(30),
  lastName:   z.string().min(1, 'Last name is required').max(30),
  address:    z.string().min(1, 'Address is required'),
  city:       z.string().min(1, 'City is required'),
  telephone:  z.string().regex(/^\d{10}$/, 'Telephone must be 10 digits')
})
type OwnerFormData = z.infer<typeof ownerSchema>
```
3. Implement the form component:
```tsx
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'

export function OwnerForm() {
  const { register, handleSubmit, setError, formState: { errors } } = useForm<OwnerFormData>({
    resolver: zodResolver(ownerSchema)
  })

  const onSubmit = async (data: OwnerFormData) => {
    const res = await fetch('/api/owners', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data), credentials: 'include' })
    if (res.status === 400) {
      const body = await res.json()
      body.errors.forEach((e: {field: string, message: string}) => setError(e.field as keyof OwnerFormData, { message: e.message }))
      return
    }
    if (res.ok) navigate(`/owners/${(await res.json()).id}`)
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <input {...register('firstName')} />
      {errors.firstName && <span className="help-block">{errors.firstName.message}</span>}
      {/* repeat for each field */}
      <button type="submit">Add Owner</button>
    </form>
  )
}
```
4. Error message text must match the existing JSP `<form:errors>` output exactly.

**Verification**
- Submit empty form → all field-level error messages appear in same position as JSP version.
- Submit valid form → navigation lands on the correct path (mirrors JSP redirect).

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - src/main/webapp/react-app/src/components/<Entity>Form.tsx (ADDED/MODIFIED)

---

### DATA_MOCK Template

Use when: `jstl-data-mock`, `mock`, `fixture`

**Context**
- This task extracts static/hardcoded data from JSP into a TypeScript fixture.
- The fixture is used by React components when `VITE_USE_MOCKS=true`.

**Step-by-Step**

1. Open each JSP file in the current slice. Search for:
   - `<c:forEach items="${...}">` where the list is hardcoded in the controller or a test scope.
   - Scriptlets (`<% %>`) that define arrays/lists.
   - `<c:set var="..." value="...">` used as a data source.
2. For each discovered static dataset, create `src/main/webapp/react-app/src/mocks/<Entity>Fixtures.ts`:
```ts
// AUTO-GENERATED from JSP static data — update when API is wired
import type { Owner } from '../types/Owner'
export const ownerFixtures: Owner[] = [
  { id: 1, firstName: 'George', lastName: 'Franklin', address: '110 W. Liberty St.', city: 'Madison', telephone: '6085551023' },
  { id: 2, firstName: 'Betty',  lastName: 'Davis',    address: '638 Cardinal Ave.',  city: 'Sun Prairie', telephone: '6085551749' }
]
```
3. Update the component to consume the fixture in mock mode:
```ts
const data = import.meta.env.VITE_USE_MOCKS === 'true' ? ownerFixtures : await fetchFromApi()
```

**Verification**
- Start dev server with `VITE_USE_MOCKS=true npm run dev`.
- React page renders with fixture data — same rows/values as JSP version.

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - src/main/webapp/react-app/src/mocks/<Entity>Fixtures.ts (ADDED)
  - src/main/webapp/react-app/src/components/<Entity>*.tsx (MODIFIED)

---

### TEST_VALIDATION Template

Use when: `functional-parity-tests`, `vitest`, `rtl`

**Context**
- Tests run with Vitest + React Testing Library.
- Every test uses the mock fixture (not the live API) for deterministic results.

**Step-by-Step**

1. Create `src/main/webapp/react-app/src/__tests__/<Entity>.test.tsx`.
2. Required test cases:
```tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { ownerFixtures } from '../mocks/OwnerFixtures'

// Test 1: empty state
test('renders empty state message when no owners found', () => {
  render(<OwnersList owners={[]} />)
  expect(screen.getByText(/no owners found/i)).toBeInTheDocument()
})

// Test 2: data-loaded render
test('renders owner list from fixtures', () => {
  render(<OwnersList owners={ownerFixtures} />)
  expect(screen.getByText('George Franklin')).toBeInTheDocument()
  expect(screen.getByText('Betty Davis')).toBeInTheDocument()
})

// Test 3: form validation error
test('shows validation errors on empty submit', async () => {
  render(<OwnerForm />)
  fireEvent.click(screen.getByRole('button', { name: /add owner/i }))
  await waitFor(() => expect(screen.getByText(/first name is required/i)).toBeInTheDocument())
})

// Test 4: successful form submit navigates
test('navigates to owner detail after successful submit', async () => {
  // mock fetch, verify useNavigate called with correct path
})
```
3. Run: `npm run test -- --run`

**Verification:**
- Validation: PASS|FAIL|NOT_RUN|SKIPPED
- Evidence: test run output
- Failures: list failing test names

---

### SESSION_COMPAT Template

Use when: `session-auth`, `csrf`, `cors`, `cookie`

**Step-by-Step**

1. All `fetch` / axios calls must include `credentials: 'include'` to forward the Spring session cookie.
2. Configure CORS in Spring (add to `WebSecurityConfigurerAdapter` or `SecurityFilterChain`):
```java
http.cors(cors -> cors.configurationSource(request -> {
    var config = new CorsConfiguration();
    config.setAllowedOrigins(List.of("http://localhost:5173"));
    config.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));
    config.setAllowCredentials(true);
    config.setAllowedHeaders(List.of("*"));
    return config;
}));
```
3. If CSRF is enabled, fetch the token before mutating calls:
```ts
async function getCsrfToken(): Promise<string> {
  const res = await fetch('/csrf', { credentials: 'include' })
  const data = await res.json()
  return data.token
}
// Include in headers: { 'X-CSRF-TOKEN': await getCsrfToken() }
```
4. Verify: POST to `/api/owners` returns 200 (not 403).

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - src/main/java/.../config/SecurityConfig.java (MODIFIED)
  - src/main/webapp/react-app/src/lib/api.ts (ADDED)

---

### DTO_CONTRACT Template

Use when: `dto-field-mapping`, `contract`

**Step-by-Step**

1. Open every JSP file in the slice. Extract all `${owner.*}`, `<form:input path="...">` expressions.
2. Cross-reference with the Java domain class (`Owner.java`) to get field types.
3. Produce the contract table:
   | Field | Java Type | JSP Expression | JSON Key | Nullable | Validation |
   |---|---|---|---|---|---|
   | firstName | String | `${owner.firstName}` | `firstName` | No | `@NotBlank @Size(max=30)` |
4. Write to `outputs/_common/dto_contract_<slice>.md`.
5. Create `src/main/webapp/react-app/src/types/<Entity>.ts`:
```ts
export interface Owner {
  id:        number
  firstName: string
  lastName:  string
  address:   string
  city:      string
  telephone: string
}
```

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - outputs/_common/dto_contract_<slice>.md (ADDED)
  - src/main/webapp/react-app/src/types/<Entity>.ts (ADDED)

---

### ERROR_PARITY Template

Use when: `error-page`, `error-boundary`

**Step-by-Step**

1. List all JSP error pages found in `WEB-INF/jsp/` (e.g., `error.jsp`, `notfound.jsp`).
2. Implement an `ErrorBoundary` React component:
```tsx
import { useRouteError } from 'react-router-dom'
export function ErrorPage() {
  const error = useRouteError() as { status?: number; statusText?: string }
  if (error.status === 404) return <div className="container"><h2>Page Not Found</h2></div>
  if (error.status === 403) return <div className="container"><h2>Access Denied</h2></div>
  return <div className="container"><h2>An error occurred: {error.statusText}</h2></div>
}
```
3. Wire as `errorElement` on the root route in `App.tsx`.
4. Match the error message text and layout to the existing JSP error pages.

**Status:** APPLIED|SKIPPED|BLOCKED
**Changes:**
  - src/main/webapp/react-app/src/pages/ErrorPage.tsx (ADDED)
  - src/main/webapp/react-app/src/App.tsx (MODIFIED)

---

### COMMIT_MSG Template

Use when: `commit-message`, `commitmsg`

**Output headers (fixed):**
- Title:         `feat(jsp-to-react): migrate <slice> views to React 18`
- Summary:       <2–3 sentences describing what was done>
- Files Changed: <list of added/modified files>
- Change Log:    <bullet list: Added X, Modified Y, Configured Z>
- Risks:         <list any known deviations or skipped steps>
- Validation:    <QA-L01 result> / <QA-L02 result>
- Rollback Plan: `git revert <commit>` — JSP fallback remains active until slice is confirmed DONE
- Approvals Needed: Frontend, Backend, QA

---

### GENERIC Template (fallback)

Use when: no Archetype keyword matched.

**Constraints:** 150–250 words. Include all Common Fields. No code skeleton required.

---

## Skill Assembly Rules

- Deterministic wording; avoid synonyms or optional phrasing.
- Do not combine phases; choose exactly one type.
- type must match the task Phase from the WBS.
- output_path must be under `outputs/` and unique per task.
- risk_behavior must reference BLOCKER/HIGH/MEDIUM/LOW with a reason.
- stop_conditions must include confidence threshold and BLOCKER detection.
- The skill must state: "Produce the artifact even if empty."
- If type is APPLY:
  - Include `Status: APPLIED|SKIPPED|BLOCKED`
  - Include `Changes:` section listing file paths
  - Include `Commands:` section with concrete executable commands
  - Include `Verification Commands:` section
- If type is VALIDATE:
  - `Validation: PASS|FAIL|NOT_RUN|SKIPPED`
  - `Evidence:`
  - `Failures:`
- If type is PLAN:
  - `Planned Changes:`
  - `Target Versions:`
  - `Files Affected:`
  - `Dependencies:`
  - `Rollback Steps:`
  - `Assumptions:`
- If `execution.enable_apply_phase` is false and type is APPLY: write Status=SKIPPED, Reason, Changes=empty.
- For Spring config tasks: populate from `outputs/_common/spring_config_migration_mapping.md`.
- For JSP_TO_REACT, additionally map each WBS task to one of `frontend_to_react/skills` files and keep both outputs synchronized.

---

## Action

- Detect the Archetype for the task (first match from the table above).
- Derive the semantic slug: lowercase, hyphens, max 5 words.
- Generate the full skill body using the matched template. Populate all code skeletons with real class/field names from the WBS task context and the DTO contract.
- Write the skill to `outputs/_global/generated_skills/<CATEGORY>-L<NN>_<semantic-slug>_skill.md`.
- Produce the artifact even if empty.
- After ALL skills for the current WBS are generated, write `outputs/_global/skill_index.json`:
```json
{
  "skills": [
    { "id": "<task_id>", "file": "<filename>", "type": "<SCAN|PLAN|APPLY|VALIDATE>", "archetype": "<ARCHETYPE>", "status": "NOT_RUN", "output_path": "<skill output_path>" }
  ]
}
```
  skill_index.json must list every skill in `wbs_execution_plan.json` order.
