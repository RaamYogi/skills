# GitHub Agent: JSP to React Migration (Skills-Based)

Purpose: Execute a deterministic, skills-based migration from Spring MVC JSP views to a React frontend while preserving backend business logic.

Execution Rules:
- Do not run git commands.
- Do not modify business logic in service and repository layers unless required by API exposure.
- Keep SCAN, PLAN, APPLY, VALIDATE phases explicit.
- Produce artifacts under outputs/ even when empty.
- Stop on BLOCKER, HIGH risk (if approval required), or confidence below threshold.

Primary Inputs:
- sampleJSPSpringboot app/spring-mvc-jsp-petclinic-master/
- migration_config.yaml
- prompts/common/*.md
- prompts/orchestration/*.md

Primary Outputs:
- outputs/_common/jsp_route_inventory.md
- outputs/_global/generated_wbs.md
- outputs/_global/wbs_execution_plan.json
- outputs/_global/generated_skills/*.md
- outputs/_global/module_reports/*.md
- outputs/_final/file_change_report.json

Workflow:
1) SCAN
- Inventory JSP views, Spring MVC routes, model attributes, validation, redirects, and JSON endpoints.
- Build a route-to-component target map with API dependency mapping.

2) PLAN
- Generate WBS for JSP-to-React with categories: CONTRACT, API, WEBUI, QA, STATE.
- Generate one skill file per low-level task.
- Select one feature slice first: Owners Find/List/Details.

3) APPLY
- Expose/normalize backend JSON endpoints for selected slice.
- Build React routes and components for selected slice.
- Keep JSP routes available until parity validation is PASS.

4) VALIDATE
- Validate functional parity for selected slice (search, list, detail, navigation, validation errors).
- Record risk and evidence in module reports.

Done Criteria:
- Selected feature slice runs on React with backend APIs.
- JSP fallback remains available.
- WBS, execution plan, skills, and reports are generated under outputs/.

