# Brain Spec (Deterministic Decision Engine)

**Purpose**
Provide a single, deterministic decision model for phase‑aware migration. This spec is used to prevent hallucinated steps and enforce consistent WBS generation.

**Inputs (Authoritative)**
- `migration_config.yaml` (phase, targets, governance)
- `outputs/_common/repo_scan.json`
- `outputs/_common/java_stack_profile.md`
- `outputs/_common/framework_classification.json`
- `outputs/_common/target_version_selection.json`
- `outputs/_common/spring_config_migration_mapping.md`

**Output (Authoritative)**
- `core/context/global_context.json`

---

## 1) Phase Contract
**Allowed phases:** `SPRING5`, `SPRING6`, `JSP_TO_REACT`, or `ANGULAR_TO_REACT`.
- If `execution.phase` is empty → set phase to `UNKNOWN` and STOP in planning.
- Phase is authoritative; do not infer a phase from the codebase.

**Phase target rules**
- `SPRING5`:
  - `targets.spring5_version` and `targets.java_version` must be set.
  - `targets.spring6_version` and `targets.tomcat10_version` must be empty.
- `SPRING6`:
  - `targets.spring6_version`, `targets.tomcat10_version`, `targets.java_version` must be set.
  - `targets.spring5_version` must be empty.
- `JSP_TO_REACT`:
  - `targets.react_version` and `targets.node_version` must be set.
  - `outputs/_common/frontend_scan.json` must have `type` in ["JSP", "HYBRID"] and `confidence >= 0.70`.
- `ANGULAR_TO_REACT`:
  - `targets.react_version` and `targets.node_version` must be set.
  - `outputs/_common/frontend_scan.json` must have `type` in ["ANGULAR", "HYBRID"] and `confidence >= 0.70`.

If violated → `target_version_selection.status = MISSING` and STOP.

---

## 2) Pattern Classification Rules (Phase‑Aware)
Only patterns relevant to the current phase may be included.

**Spring patterns**
- `springx-to-spring5` → only when Spring version starts with 2.x/3.x/4.x.
- `spring5-to-spring6` → only when phase is `SPRING6` or `targets.spring6_version` is set.
- `spring6-to-springboot3` → only when phase is `SPRING6` and Boot 2.x detected.

**Tomcat patterns**
- `tomcat8-to-tomcat10` / `tomcat9-to-tomcat10` → only when phase is `SPRING6` or `targets.tomcat10_version` is set.
- `tomcat-pre10-to-10` → only when `targets.tomcat10_version` is set and pre‑10 evidence exists.

**Java patterns**
- `java8-to-java17`, `java11-to-java17`, `java9plus-to-java17` → based on detected Java level.

**View patterns**
- `jsp-view-compatibility` → when JSP/taglib evidence exists.

**Angular-to-React patterns** (phase = `ANGULAR_TO_REACT` only)
- `angular-to-react` → always active when phase is ANGULAR_TO_REACT.
- `angular-routing-to-react-router` → when `RouterModule` or lazy-loaded routes are detected.
- `angular-forms-to-react-hook-form` → when `ReactiveFormsModule` or `FormsModule` is detected.
- `angular-services-to-react-hooks` → when `@Injectable` or Angular `HttpClient` is detected.
- `rxjs-to-custom-hooks` → when RxJS Observable patterns are detected in component files.

**JSP-to-React patterns** (phase = `JSP_TO_REACT` only)
- `jsp-to-react-component` → when JSP view files exist in WEB-INF/jsp/.
- `spring-mvc-to-rest-api` → when Spring MVC @RequestMapping returns ModelAndView or ViewName.

If no rule matches → pattern = `unknown` and STOP.

---

## 3) Capability Derivation (Phase‑Aware)
Capabilities are derived from patterns and phase constraints.

- If phase = `SPRING5`:
  - `requires_spring6 = false`
  - `requires_jakarta = false`
  - `requires_tomcat10 = false`
- Otherwise:
  - `requires_spring6 = true` only if pattern `spring5-to-spring6` exists.
  - `requires_jakarta = true` if any Tomcat 10 or Spring 6 pattern exists.
  - `requires_tomcat10 = true` if any Tomcat 10 pattern exists.

Always derive:
- `requires_java17` when detected Java < 17 and target Java >= 17.
- `requires_jspview` when JSP evidence exists.
- `requires_dependency_convergence` when `requires_spring6` or `requires_jakarta` is true, or when Spring baseline upgrade is required.
- `requires_container_compat` when `requires_jakarta` is true or app server known.
- `requires_view_render_checks` when JSP + Jakarta.
- `requires_internal_dependency_review` when unclassified/internal deps exist.
- `requires_annotation_api` when javax/jakarta annotation usage detected and Java >= 17.

For phase = `JSP_TO_REACT`:
- `requires_react_host` = true always.
- `requires_api_contract` = true always.
- `requires_form_parity` = true when any JSP form (method=POST) detected.
- `requires_routing_parity` = true when more than one JSP view path exists.

For phase = `ANGULAR_TO_REACT`:
- `requires_state_management` = true when NgRx store or complex service state is detected.
- `requires_api_client_parity` = true always (HttpClient calls must be replicated via fetch/axios layer).
- `requires_component_testing` = true always.
- `requires_form_parity` = true when FormsModule or ReactiveFormsModule detected.
- `requires_routing_parity` = true when RouterModule detected.

---

## 4) WBS Generation Rules (Phase‑Aware)
WBS tasks are generated only if their pattern or capability is true.

**Phase 1 (SPRING5) WBS**
- Allowed modules: JAVA, STRUTS, SPRINGX, HIBERNATE, JSPVIEW, DEPENDENCY, CONTAINER, ANNOTATION, COMMITMSG.
- Disallowed: JAKARTA, TOMCAT, SPRING5 (Spring6), SPRINGBOOT3.

**Phase 2 (SPRING6) WBS**
- Allowed modules: JAVA, JAKARTA, TOMCAT, SPRING5 (Spring6 upgrade), DEPENDENCY, CONTAINER, JSPVIEW, ANNOTATION, COMMITMSG.
- Disallowed: STRUTS/SPRINGX unless still detected (only include if present in scan).

**JSP_TO_REACT WBS**
- Allowed modules: CONTRACT, API, WEBUI, ROUTING, FORMS, QA, STATE, COMMITMSG.
- Dispatch to: prompts/wbs/jsp_to_react_wbs.md
- Must have frontend_scan.json with type in ["JSP", "HYBRID"].

**ANGULAR_TO_REACT WBS**
- Allowed modules: CONTRACT, COMPONENT, SERVICE, ROUTING, FORMS, HTTPCLIENT, STATE, QA, COMMITMSG.
- Dispatch to: prompts/wbs/angular_to_react_wbs.md
- Must have frontend_scan.json with type in ["ANGULAR", "HYBRID"].

---

## 5) Gating Rules (Phase‑Aware)
**SPRING5 baseline run:**
- No Jakarta/Tomcat gating.

**SPRING6 run:**
- JAKARTA must validate before TOMCAT.
- SPRING5 (Spring 6 upgrade) requires JAVA/DEPENDENCY/CONTAINER/JAKARTA validation.

**JSP_TO_REACT run:**
- CONTRACT must validate before API tasks may start.
- API APPLY must complete before WEBUI APPLY tasks.
- QA-L01 must PASS before STATE-L01 may run.

**ANGULAR_TO_REACT run:**
- CONTRACT must validate before COMPONENT/FORMS/SERVICE tasks.
- HTTPCLIENT and SERVICE must complete before COMPONENT APPLY.
- ROUTING must complete before COMPONENT final wiring (WEBUI phase).
- QA must PASS before STATE and COMMITMSG.

If `execution.allow_skip_validation=true`, allow `SKIPPED` with HIGH risk noted.

---

## 6) Determinism Guarantees
- No web access or external lookups.
- Stable ordering and fixed header outputs only.
- Every prompt produces an artifact even if empty.

---

## 7) Stop Conditions (Non‑Negotiable)
- Conflicting targets.
- Missing required targets.
- Phase unknown.
- Confidence below threshold.
- `frontend_scan.type` does not match the declared phase (e.g., ANGULAR_TO_REACT but scan shows JSP).
- `frontend_scan.confidence < 0.70` for JSP_TO_REACT or ANGULAR_TO_REACT phases.
- JAVA_HOME not set when `targets.java_version` is specified: emit ENV-CHECK BLOCKER and STOP.
- GitLab PAT placeholder `{{GITLAB_PAT}}` still present in migration_config.yaml when source_type=gitlab: emit AUTH BLOCKER and STOP.

