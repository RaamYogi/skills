# RUNBOOK (Copy-Paste Safe)

**Purpose**
This runbook is a single source of truth to run the Prompt‑Only Migration OS in any IDE (Copilot, VS Code Agentic, etc). It prevents skipped steps and enforces deterministic artifacts.

**Important**
Run the framework twice for a full migration:
1) Phase 1 (Spring 5 + JDK17 + Tomcat9)
2) Phase 2 (Spring 6 + Jakarta + Tomcat10 + JDK21)
Each phase is a separate run with its own targets and WBS.

**Golden Rule**
Only paste the **Copy‑Paste Run Prompt** section into the agent. Do not paste this entire file.

**Preflight (Every Run)**
1. Open the framework repo root (this repository): `<FRAMEWORK_REPO_ROOT>`.
2. Ensure execution path is a clean copy of the input source path. If it exists and is not empty, stop and create a fresh directory.
3. If a clean run is required, set `execution.output_path` to a new folder or manually clear old artifacts outside the agent. The agent must not delete files.
4. Create `outputs/_global/generated_skills/` if missing.
5. The execution path must contain only the migrated codebase. Never write framework outputs into the execution path.

**Phase Presets (Pick One)**
Phase 1 (Spring 5 + JDK17 + Tomcat9):
```
targets:
  spring5_version: "5.3.39"
  spring_security5_version: "5.8.16"
  hibernate_version: "5.6.15.Final"
  tomcat10_version: ""
  spring6_version: ""
  spring_security6_version: ""
  spring_boot3_version: ""
  java_version: "17"
```

Phase 2 (Spring 6 + Jakarta + Tomcat10 + JDK21):
```
targets:
  spring5_version: ""
  spring_security5_version: ""
  hibernate_version: ""
  tomcat10_version: "10.1.52"
  spring6_version: "6.2.11"
  spring_security6_version: "6.4.13"
  spring_boot3_version: ""
  java_version: "21"
```

**Validation Defaults**
- For Maven, use `mvn clean install -DskipTests`.
- If `settings.xml` exists in the repo root, use `mvn clean install -DskipTests -s settings.xml`.
- If runtime commands are missing, record `NOT_RUN` but do not fail the build.

**Copy‑Paste Run Prompt (Agent Mode)**
```
You are the Enterprise Migration Automation Architect.
Use the prompt-based migration framework in this repo only. Prompt-only execution; no hidden logic.
Target codebase: <PATH_TO_SOURCE_REPO>
Execution path (working copy): <PATH_TO_EXECUTION_REPO>
Framework repo root: <FRAMEWORK_REPO_ROOT>

Hard rules:
- Do not run git commands.
- Do not assume frameworks not in the repo.
- Deterministic outputs only.
- Separate SCAN, PLAN, APPLY, VALIDATE phases.
- Produce every artifact even if empty.
- Stop on BLOCKER, HIGH risk (when require_approval_for_high_risk=true), and low confidence.

Preflight (do this first):
- Ensure the execution path is a clean copy of the input source path. If it exists and is not empty, stop and create a fresh directory.
- If a clean run is required, set `execution.output_path` to a new folder or manually clear old artifacts outside the agent. The agent must not delete files.
- Create `outputs/_global/generated_skills/` if missing.
- Never write framework outputs into the execution path.

Phase Presets (pick one and apply to migration_config.yaml):
Phase 1 (Spring 5 + JDK17 + Tomcat9):

targets:
  spring5_version: "5.3.39"
  spring_security5_version: "5.8.16"
  hibernate_version: "5.6.15.Final"
  tomcat10_version: ""
  spring6_version: ""
  spring_security6_version: ""
  spring_boot3_version: ""
  java_version: "17"

Phase 2 (Spring 6 + Jakarta + Tomcat10 + JDK21):

targets:
  spring5_version: ""
  spring_security5_version: ""
  hibernate_version: ""
  tomcat10_version: "10.1.52"
  spring6_version: "6.2.11"
  spring_security6_version: "6.4.13"
  spring_boot3_version: ""
  java_version: "21"


Step 1: Update migration_config.yaml
- Set input.source_path to <PATH_TO_SOURCE_REPO>
- Set execution.source_code_path to <PATH_TO_EXECUTION_REPO>
- Set execution.phase to SPRING5 or SPRING6.
- Set execution.enable_apply_phase to true for APPLY runs; false for plan‑only runs.
- Set execution.allow_skip_validation according to policy (true only if you accept HIGH risk for skipped validation).
- Set targets.* for the phase (Spring5 or Spring6).
- Ensure only the active phase targets are set; all non-phase targets must be empty.
- Set dependency_policy.* if internal libs exist.

Step 2: Input Acquisition + Baseline
- Run prompts/common/git_clone.md (filesystem inputs are copied to execution path; ensure this is a full replace of the execution path).
- Run prompts/common/file_inventory_baseline.md to produce outputs/_common/file_manifest_baseline.json.

Step 3: Scan (SCAN phase)
- Run prompts/common/repository_scan.md.
- Run prompts/common/java_stack_profile.md.

Step 4: Plan (PLAN phase)
- Run prompts/common/framework_classification.md.
- Run prompts/common/target_version_selection.md. If status=MISSING, stop.
- Run prompts/common/spring_config_migration_mapping.md.
- Run prompts/common/global_context.md (must apply core/context/brain_spec.md rules).
- Run prompts/common/wbs_generator.md.
- Run prompts/common/wbs_router.md.
- Run prompts/common/state_checkpoint.md.
- For each Low-Level task in outputs/_global/generated_wbs.md, run prompts/orchestration/skill_generator.md.

Step 5: Apply + Validate (APPLY/VALIDATE phases)
- Execute each generated skill in outputs/_global/generated_skills/ using the execution order in outputs/_global/wbs_execution_plan.json.
- If execution.enable_apply_phase=false, write APPLY artifacts with Status: SKIPPED.
- For Maven, run mvn clean install -DskipTests for build validation.
- If settings.xml exists at repo root, use mvn clean install -DskipTests -s settings.xml.
- If runtime validation commands are missing, record NOT_RUN but do not fail the build.
- Update outputs/_global/module_reports/*.md.

Step 6: Change Report + Consolidation
- Run prompts/common/file_change_report.md to create outputs/_final/file_change_report.json.
- Run prompts/orchestration/mr_consolidation.md.
- Run prompts/orchestration/html_report_generator.md.
- If COMMITMSG-L01 exists in the WBS, run it to create outputs/_final/commit_message.md.
- Run prompts/common/state_checkpoint.md again.

Do not skip steps. All outputs must be written under outputs/.
```

**HTML Report Location**
`outputs/_final/migration_report.html`

**Troubleshooting (Quick)**
1. If HTML report not visible, re-run `prompts/orchestration/html_report_generator.md` and ensure VS Code is not excluding `outputs/`.
2. If execution path is not clean, stop and create a fresh directory. Do not overwrite an existing non-empty execution path.
3. If Struts still exists after APPLY, the STRUTS module was not executed or failed. Re-run STRUTS apply and update artifacts.

**Notes**
- Outputs are deterministic. If you re-run a phase, overwrite the prior artifact file.
- The framework never deletes the execution path; it only reads/writes inside it after a clean copy is created.
