# Agent Runbook (Prompt-Only Migration OS)

**Note**
Use `RUNBOOK.md` for copy‑paste execution. This file is a reference guide, not the copy‑paste prompt.

**Purpose**
Use this as the exact playbook for running the framework in VS Code agentic mode against a single codebase.

**Preflight (Every Run)**
1. Ensure you are in the framework repo root: `<FRAMEWORK_REPO_ROOT>`.
2. Ensure the execution path is a clean copy of the input source. If it already exists, replace it fully before scanning.
3. If a clean run is required, set `execution.output_path` to a new folder or manually clear old artifacts outside the agent. The agent must not delete files.
4. Create `outputs/_global/generated_skills/` before skill generation (if missing).
5. The execution path must contain only the migrated codebase. Never write framework outputs inside the execution path.

**Do You Need to Update `migration_config.yaml`?**
Yes. Each target repository run must set:
1. `input.source_path`
2. `execution.source_code_path`
3. `targets.*` versions for the intended phase
4. `dependency_policy.*` to flag internal/company dependencies (optional but recommended)

Note: If `input.source_path` differs from `execution.source_code_path`, the framework copies the full source tree to the execution path before any scans or plans. All work is performed on the execution path.

You can either:
1. Update `migration_config.yaml` manually, or
2. Ask the agent to update it as the first step in its run

**Recommended Settings Per Phase**
Phase 1 (Spring 5 + JDK17 + Tomcat9):
1. `targets.spring5_version=5.3.39`
2. `targets.java_version=17`
3. `targets.tomcat10_version` empty

Phase 2 (Spring 6 + Jakarta + Tomcat10):
1. `targets.spring6_version=6.2.11`
2. `targets.java_version=17` or `21`
3. `targets.tomcat10_version=10.1.52`

**Phase Presets (Copy/Paste)**
Phase 1 (Spring 5 + JDK17 + Tomcat9):
```
targets:
  spring5_version: "5.3.39"
  spring_security5_version: "5.8.16"
  hibernate_version: "5.6.15.Final"
  tomcat10_version: ""
  spring6_version: ""
  spring_security6_version: ""
  spring_boot3_version: ""
  java_version: "17"
```

Phase 2 (Spring 6 + Jakarta + Tomcat10 + JDK21):
```
targets:
  spring5_version: ""
  spring_security5_version: ""
  hibernate_version: ""
  tomcat10_version: "10.1.52"
  spring6_version: "6.2.11"
  spring_security6_version: "6.4.13"
  spring_boot3_version: ""
  java_version: "21"
```

**Full Copy-Paste Run Prompt (Agent Mode)**
Copy and paste ONLY the block below into the agent. Do not paste the entire runbook file.
This block is the authoritative run prompt:
```
You are the Enterprise Migration Automation Architect.
Use the prompt-based migration framework in this repo only. Prompt-only execution; no hidden logic.
Target codebase: <PATH_TO_SOURCE_REPO>
Execution path (working copy): <PATH_TO_EXECUTION_REPO>

Hard rules:
- Do not run git commands.
- Do not assume frameworks not in the repo.
- Deterministic outputs only.
- Separate SCAN, PLAN, APPLY, VALIDATE phases.
- Produce every artifact even if empty.
- Stop on BLOCKER, HIGH risk (when require_approval_for_high_risk=true), and low confidence.

Step 1: Update migration_config.yaml
- Set input.source_path to <PATH_TO_SOURCE_REPO>
- Set execution.source_code_path to <PATH_TO_EXECUTION_REPO>
- Set execution.phase to SPRING5 or SPRING6.
- Set execution.enable_apply_phase to true for APPLY runs; false for plan‑only runs.
- Set execution.allow_skip_validation according to policy (true only if you accept HIGH risk for skipped validation).
- Set targets.* for the phase (Spring5 or Spring6).
- Ensure only the active phase targets are set; all non-phase targets must be empty.
- Set dependency_policy.* if internal libs exist.

Step 2: Input Acquisition + Baseline
- Run prompts/common/git_clone.md (filesystem inputs are copied to execution path; ensure this is a full replace of the execution path).
- Run prompts/common/file_inventory_baseline.md to produce outputs/_common/file_manifest_baseline.json.

**Execution Path Hygiene**
- The framework will NOT delete or clean the execution path (non‑destructive rule).
- If the execution path exists and is not empty, stop and require a manual clean copy.
- Use a fresh directory per run (recommended) to guarantee only updated files are present.

Step 3: Scan (SCAN phase)
- Run prompts/common/repository_scan.md.
- Run prompts/common/java_stack_profile.md.

Step 4: Plan (PLAN phase)
- Run prompts/common/framework_classification.md.
- Run prompts/common/target_version_selection.md. If status=MISSING, stop.
- Run prompts/common/spring_config_migration_mapping.md.
- Run prompts/common/global_context.md.
- Run prompts/common/wbs_generator.md.
- Run prompts/common/wbs_router.md.
- Run prompts/common/state_checkpoint.md.
- For each Low-Level task in outputs/_global/generated_wbs.md, run prompts/orchestration/skill_generator.md.

Step 5: Apply + Validate (APPLY/VALIDATE phases)
- Execute each generated skill in outputs/_global/generated_skills/ using the execution order in outputs/_global/wbs_execution_plan.json.
- If execution.enable_apply_phase=false, write APPLY artifacts with Status: SKIPPED.
- For Maven, run mvn clean install -DskipTests for build validation.
- If settings.xml exists at repo root, use mvn clean install -DskipTests -s settings.xml.
- If runtime validation commands are missing, record NOT_RUN but do not fail the build.
- Update outputs/_global/module_reports/*.md.

Step 6: Change Report + Consolidation
- Run prompts/common/file_change_report.md to create outputs/_final/file_change_report.json.
- Run prompts/orchestration/mr_consolidation.md.
- Run prompts/orchestration/html_report_generator.md.
- If COMMITMSG-L01 exists in the WBS, run it to create outputs/_final/commit_message.md.
- Run prompts/common/state_checkpoint.md again.

Do not skip steps. All outputs must be written under outputs/.

**HTML Report Location**
`outputs/_final/migration_report.html`

**If You Do Not See the HTML in VS Code**
1. Confirm the file exists on disk at `outputs/_final/migration_report.html`.
2. Re-run `prompts/orchestration/html_report_generator.md` to regenerate it.
3. Check VS Code settings `files.exclude` or `search.exclude` for `outputs/` and remove exclusions.
```

**Quick Start (One Line)**
```
You are the Enterprise Migration Automation Architect. Update migration_config.yaml for <PATH_TO_SOURCE_REPO> and <PATH_TO_EXECUTION_REPO>, then run: git_clone → file_inventory_baseline → repository_scan → java_stack_profile → framework_classification → target_version_selection → spring_config_migration_mapping → global_context → wbs_generator → wbs_router → state_checkpoint → skill_generator → execute skills → file_change_report → mr_consolidation → html_report_generator → commit_message → state_checkpoint. No git commands.
```

**Optional Runtime Validation (if you have commands)**
If you have Tomcat startup and base URL, append this to the prompt:
```
Use Tomcat 10.1.x for runtime validation.
Startup command: <your_tomcat_start_command>
Base URL: http://localhost:8080
Validate endpoints: /bookList, /addBook, /editBook?bookId=1
```

**Dockerization (Manual Run)**
Docker templates are generated but not executed:
1. Phase 1 templates: outputs/docker/phase1/
2. Phase 2 templates: outputs/docker/phase2/

These are intentionally not executed in automated runs.
