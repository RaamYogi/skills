# Migration Automation Operating System (Prompt-Only)

> For the full component diagram, data flow table, Archetype system, safety model, and live demo script, see [ARCHITECTURE.md](ARCHITECTURE.md).

**Purpose**
A prompt-based, deterministic, model-agnostic framework for Java tech stack upgrades. The system is modular and produces structured artifacts for every execution step. It separates SCAN, PLAN, APPLY, and VALIDATE phases and generates a final Merge Request summary.

**Core Principles**
- Prompt-only execution, no hidden automation logic
- Model-agnostic prompts
- Deterministic outputs with stable ordering
- Structured outputs only (JSON or fixed-header Markdown)
- Explicit separation of SCAN, PLAN, APPLY, VALIDATE
- Artifact produced for every prompt even if empty

**Target Migrations (Pattern-Driven)**

_Frontend UI Migration (use `SINGLE_COPY_PASTE_PROMPT_JSP_TO_REACT.md`):_
- **JSP → React 18** — Spring Boot + JSP frontend migrated to React 18 + Vite + TypeScript. Backend untouched. Covers: look-and-feel parity, JSTL mock data extraction, form/validation parity, session/auth compatibility, error-page parity, visual regression QA.

_Backend / Stack Upgrades (use the backend prompts under `prompts/`):_
- Struts to Spring 5
- Hibernate to Spring 5
- Legacy Spring (2.x–4.x) to Spring 5
- Java 8 to Java 17
- JSP/View compatibility for Spring MVC
- Jakarta namespace migration
- Dependency convergence (Spring/Jakarta/Hibernate/Jackson/Servlet)
- Container compatibility alignment
- Annotation API alignment (javax.annotation/jakarta.annotation)
- Spring 5 to Spring 6
- Spring 6 to Spring Boot 3
- Tomcat 9 to Tomcat 10
- Commit message generation (post-migration summary)

**Repository Structure**
- `core/`
- `core/context/`
- `core/governance/`
- `core/orchestrator/`
- `core/state/`
- `prompts/`
- `prompts/common/`
- `prompts/guardrails/`
- `prompts/orchestration/`
- `prompts/philosophy/`
- `prompts/wbs/`
- `outputs/`
- `outputs/_common/`
- `outputs/_global/`
- `outputs/_final/`

**Execution Flow — JSP → React (Frontend Migration)**
1. ENV CHECK — Java, Node, Maven, Git, PAT sanity
2. SOURCE ACQUISITION — `git clone` (GitHub/GitLab) or verify filesystem path
3. SCAN — `repository_scan`, `java_stack_profile`, `framework_classification`, `jsp_route_inventory`, `global_context`
4. 🛑 GATE 1 — Review scan results before planning
5. PLAN — `jsp_to_react_wbs` → WBS file; `wbs_router` → execution plan
6. 🛑 GATE 2 — Review WBS plan before skill generation
7. SKILL GENERATION — Archetype-driven (REST_API, REACT_SCAFFOLD, STYLE_PARITY, FORM_VALIDATION, DATA_MOCK, TEST_VALIDATION, SESSION_COMPAT, DTO_CONTRACT, ERROR_PARITY)
8. 🛑 GATE 3 — Spot-check generated skills contain code skeletons
9. APPLY — Execute each skill in category order; JSP fallback (G-02) stays active throughout
10. 🛑 GATE 4 — Review after WEBUI, FORMS, and COMPAT categories
11. VALIDATE — Vitest functional parity tests + visual regression + Maven build
12. CONSOLIDATE — File change report, MR description, HTML summary report

**Execution Flow — Backend / Stack Upgrade**
1. Input acquisition (GitLab, GitHub, or filesystem)
2. Repository scan (structured JSON)
3. Java stack profile (routing `.md`)
4. Framework classification (patterns JSON)
5. Target version selection (prompted; uses `migration_config.yaml` targets)
6. Spring config migration mapping (Spring 3.x/4.x schemas)
7. Global context synthesis (single “brain” artifact)
8. WBS generation (pattern → granular tasks)
9. WBS routing (category order + phase order)
10. Skill generation (one per low-level task)
11. Module orchestration (sequential execution, stop on BLOCKER)
12. MR consolidation (final summary)
13. Commit message generation (detailed, deterministic)

**Gating Rules**
- Struts, Hibernate, Legacy Spring, JSP View, Java, Annotation, Jakarta, Dependency, and Container modules must validate PASS before the Spring 5 → 6 module runs.
- Spring 5 → 6 must validate PASS before Spring 6 → Boot 3.
- Tomcat 10 alignment requires Jakarta and Container validation PASS (or SKIPPED if `execution.allow_skip_validation=true`).

**Operational Runbooks**
See `RUNBOOK.md` for execution steps and `AGENT_RUNBOOK.md` for reference guidance.

**Block Diagram**
```mermaid
flowchart TB
  A["Input Acquisition<br/>GitLab, GitHub, Filesystem"] --> B0["File Baseline<br/>outputs/_common/file_manifest_baseline.json"]
  B0 --> B["Repository Scan<br/>outputs/_common/repo_scan.json"]
  B --> C["Java Stack Profile<br/>outputs/_common/java_stack_profile.md"]
  C --> D["Framework Classification<br/>outputs/_common/framework_classification.json"]
  D --> E["Target Version Selection<br/>outputs/_common/target_version_selection.json"]
  E --> F{"Targets Complete?"}
  F -->|No| X["STOP: Missing Targets<br/>Record in Global Report"]
  F -->|Yes| G["Spring Config Mapping<br/>outputs/_common/spring_config_migration_mapping.md"]
  G --> H["Global Context<br/>core/context/global_context.json"]
  H --> I["WBS Generator<br/>outputs/_global/generated_wbs.md"]
  I --> J["WBS Router<br/>outputs/_global/wbs_execution_plan.json"]
  J --> S["State Checkpoint<br/>core/state/migration_state.json"]
  S --> K["Skill Generator<br/>outputs/_global/generated_skills/*.md"]
  K --> L["Module Orchestrator<br/>outputs/_global/module_reports/*.md"]
  L --> FC["File Change Report<br/>outputs/_final/file_change_report.json"]
  FC --> M["MR Consolidation<br/>outputs/_final/merge_request_description.md"]
  M --> R["HTML Report<br/>outputs/_final/migration_report.html"]
  R --> CM["Commit Message<br/>outputs/_final/commit_message.md"]
  K --> AG1

  subgraph ApplyGuard
    AG1{"Plan Has Targets<br/>And Config Change List?"}
    AG1 -->|No| AG2["BLOCK APPLY<br/>Status: BLOCKED"]
    AG1 -->|Yes| AG3["APPLY"]
  end

  subgraph Gating
    H1["JAVA, ANNOTATION, JAKARTA, DEPENDENCY, CONTAINER, STRUTS, HIBERNATE, SPRINGX, JSPVIEW<br/>Validation PASS"] --> H2["SPRING5"]
    H2 --> H3["SPRINGBOOT3"]
  end
```

**UML Diagram (Component View)**
```mermaid
classDiagram
class GlobalOrchestrator {
  +run()
}
class ModuleOrchestrator {
  +executeModule()
}
class WBSGenerator {
  +generate()
}
class WBSRouter {
  +route()
}
class SkillGenerator {
  +createSkill()
}
class StateCheckpoint {
  +updateState()
}
class BrainSpec {
  +rules
}
class GlobalContext {
  +phase
  +capabilities
}
class MigrationConfig {
  +phase
  +targets
  +governance
}
class OutputsCommon
class OutputsGlobal
class OutputsFinal
class StateStore
class DockerPhase1 {
  +Phase: Spring 5
  +Tomcat 9
  +JDK 17
}
class DockerPhase2 {
  +Phase: Spring 6
  +Tomcat 10
  +JDK 17/21
}

GlobalOrchestrator --> MigrationConfig
GlobalOrchestrator --> BrainSpec
GlobalOrchestrator --> GlobalContext
GlobalOrchestrator --> WBSGenerator
GlobalOrchestrator --> WBSRouter
GlobalOrchestrator --> StateCheckpoint
GlobalOrchestrator --> ModuleOrchestrator
ModuleOrchestrator --> SkillGenerator
WBSGenerator --> OutputsGlobal
WBSRouter --> OutputsGlobal
SkillGenerator --> OutputsGlobal
ModuleOrchestrator --> OutputsGlobal
ModuleOrchestrator --> OutputsFinal
GlobalContext --> OutputsGlobal
StateCheckpoint --> StateStore
GlobalOrchestrator --> OutputsCommon
OutputsFinal --> OutputsCommon : summarize
ModuleOrchestrator --> DockerPhase1 : after Phase1 build PASS
ModuleOrchestrator --> DockerPhase2 : after Phase2 build PASS
```

**Architecture Diagram (Agentic Brain + Layers)**
```mermaid
flowchart TB
  subgraph L1["Layer 1: Inputs"]
    A["migration_config.yaml"]
    B["repo_scan.json"]
    C["java_stack_profile.md"]
    D["framework_classification.json"]
    E["target_version_selection.json"]
    F["spring_config_migration_mapping.md"]
  end

  subgraph L2["Layer 2: Agentic Brain"]
    G["brain_spec.md<br/>Rules + Phase Contract"]
    H["global_context.json<br/>Phase + Capabilities"]
    I["Decision Gates<br/>Targets, Phase, Risk"]
  end

  subgraph L3["Layer 3: Planning"]
    J["WBS Generator"]
    K["WBS Router"]
    L["Skill Generator"]
  end

  subgraph L4["Layer 4: Execution"]
    M["Module Orchestrator"]
    N["SCAN | PLAN | APPLY | VALIDATE"]
  end

  subgraph L5["Layer 5: Artifacts"]
    O["module_reports/*.md"]
    P["file_change_report.json"]
    Q["merge_request_description.md"]
    R["migration_report.html"]
    S["commit_message.md"]
  end

  A --> H
  B --> H
  C --> H
  D --> H
  E --> H
  F --> H
  G --> H
  H --> I
  I --> J
  J --> K
  K --> L
  L --> M
  M --> N
  N --> O
  O --> P
  P --> Q
  Q --> R
  R --> S
```

**Context vs State (2‑Entity Diagram)**
```mermaid
flowchart LR
  GC["Global Context<br/>What should be done?"] -->|drives| WBS["WBS Generation"]
  ST["Migration State<br/>What is ready to run?"] -->|gates| EXEC["Module Execution"]
```
**Explanation:** Global Context decides *what* modules are needed; Migration State decides *when* they can run.

**Notes**
- The framework is designed to be extended by adding new pattern mappings in `prompts/common/wbs_generator.md` and classification rules in `prompts/common/framework_classification.md`.
- All outputs are deterministic and stored under `outputs/`.
- Decision rules are centralized in `core/context/brain_spec.md` and must be applied by the global context prompt.
