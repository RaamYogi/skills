# Framework Architecture — JSP to React Migration Orchestrator

> **Quick start:** Fill the 5 tokens in `SINGLE_COPY_PASTE_PROMPT_JSP_TO_REACT.md`, paste the whole file into your AI agent, and follow the 4 gated checkpoints.

---

## Section 1 — What This Framework Is

This is a **prompt-only, model-agnostic migration engine**. It has no executable code — every "step" is a Markdown prompt file that an AI agent reads and acts on. The agent produces a structured artifact (JSON or Markdown) after every step, even if that artifact is empty. Nothing is implicit; nothing is invented.

The framework is purpose-built for one migration path: **Spring Boot + JSP frontend → React 18**. The Spring Boot backend is never touched. Only `@RestController` adapter endpoints are added alongside existing `@Controller` JSP mappings. The original JSP application stays fully functional as a fallback until the very last validation step confirms the React replacement is correct — at which point JSP routes are decommissioned slice by slice.

---

## Section 2 — Component Diagram

```
╔══════════════════════════════════════════════════════════════════════════╗
║  LAYER 1 — ENTRY POINT                                                   ║
║                                                                          ║
║  SINGLE_COPY_PASTE_PROMPT_JSP_TO_REACT.md                                ║
║  • Fill 5 tokens (repo URL/path, source type, PAT, branch)               ║
║  • Drives 6 phases: ENV → ACQUIRE → SCAN → PLAN → APPLY → VALIDATE       ║
║  • 4 Human-in-the-Loop 🛑 gates enforce review before each major phase   ║
╚══════════════════════════╦═══════════════════════════════════════════════╝
                           ║ invokes prompts in order
╔══════════════════════════▼═══════════════════════════════════════════════╗
║  LAYER 2 — BRAIN  (core/context/)                                        ║
║                                                                          ║
║  brain_spec.md  ──────────────────────────►  global_context.json        ║
║                                                                          ║
║  Rules stored in brain_spec.md:                                          ║
║  • Phase contract       (JSP_TO_REACT / SPRING5 / SPRING6 / ANGULAR)     ║
║  • Pattern classification (which migration patterns apply)               ║
║  • Capability derivation  (requires_react_host, requires_form_parity…)  ║
║  • WBS gating rules       (CONTRACT before API, API before WEBUI…)      ║
║  • Stop conditions        (wrong phase, low confidence, missing targets) ║
╚═══════╦══════════════════════════════════════╦════════════════════════════╝
        ║                                      ║
╔═══════▼════════════════════╗   ╔═════════════▼══════════════════════════╗
║  LAYER 3A — SCAN           ║   ║  LAYER 3B — ORCHESTRATORS              ║
║  prompts/common/           ║   ║  prompts/orchestration/                ║
║                            ║   ║                                        ║
║  repository_scan.md        ║   ║  global_orchestrator.md                ║
║    └► repo_scan.json       ║   ║    └► global_orchestration_report.md   ║
║                            ║   ║                                        ║
║  java_stack_profile.md     ║   ║  module_orchestrator.md                ║
║    └► java_stack_profile   ║   ║    └► module_reports/<id>_report.md    ║
║                            ║   ║                                        ║
║  framework_classification  ║   ║  skill_generator.md  ◄── ARCHETYPES    ║
║    └► classification.json  ║   ║    └► generated_skills/*_skill.md      ║
║                            ║   ║       + skill_index.json               ║
║  JSP route inventory       ║   ║                                        ║
║    └► jsp_route_inventory  ║   ║  orchestration_trace.md                ║
║                            ║   ║    └► execution_trace.json  (resume)   ║
║  global_context.md         ║   ║                                        ║
║    └► global_context.json  ║   ║  mr_consolidation.md                   ║
║                            ║   ║    └► merge_request_description.md     ║
║  target_version_selec.     ║   ║                                        ║
║    └► target_versions.json ║   ║  html_report_generator.md              ║
║                            ║   ║    └► migration_report.html            ║
║  spring_config_mapping     ║   ║                                        ║
║    └► spring_config_map    ║   ╚═════════════╦══════════════════════════╝
╚═══════╦════════════════════╝                 ║
        ║                                      ║
╔═══════▼════════════════════╗                 ║
║  LAYER 3C — WBS / PLAN     ║                 ║
║  prompts/wbs/              ║                 ║
║                            ║                 ║
║  jsp_to_react_wbs.md       ║                 ║
║    └► generated_wbs.md     ║                 ║
║                            ║                 ║
║  wbs_router.md             ║                 ║
║    └► wbs_execution_       ║                 ║
║       plan.json            ║                 ║
╚═══════╦════════════════════╝                 ║
        ║  feeds task list                     ║
        ╚═══════════════════════╦══════════════╝
                                ║ skill_generator runs once per task
╔═══════════════════════════════▼══════════════════════════════════════════╗
║  LAYER 4 — SKILLS  (outputs/_global/generated_skills/)                   ║
║                                                                          ║
║  Each file is a self-contained prompt generated by the Archetype engine  ║
║                                                                          ║
║  REST_API         → @RestController skeleton, Java record DTO            ║
║  REACT_SCAFFOLD   → vite.config.ts, App.tsx, React Router v6            ║
║  STYLE_PARITY     → Bootstrap class mapping, conditional className       ║
║  FORM_VALIDATION  → react-hook-form + Zod schema, error display          ║
║  DATA_MOCK        → TypeScript fixture extracted from JSTL data          ║
║  TEST_VALIDATION  → Vitest + RTL test bodies, 6 required test cases      ║
║  SESSION_COMPAT   → CORS config, credentials:'include', CSRF token       ║
║  DTO_CONTRACT     → Field table from JSP ${model.*} bindings             ║
║  ERROR_PARITY     → React Error Boundary, route error elements           ║
║  COMMIT_MSG       → Conventional commit with evidence summary            ║
╚═══════════════════════════════╦══════════════════════════════════════════╝
                                ║ executed in category order
╔═══════════════════════════════▼══════════════════════════════════════════╗
║  LAYER 5 — OUTPUTS  (filesystem artifacts)                               ║
║                                                                          ║
║  outputs/_common/        ← SCAN phase results (JSON/MD)                 ║
║  outputs/_global/        ← WBS, skills, module reports, skill index     ║
║  outputs/_validation/    ← QA functional + visual regression results    ║
║  outputs/_final/         ← MR description, HTML report, commit msg      ║
║  core/context/           ← global_context.json  (Brain output)          ║
║  core/state/             ← migration_state.json  (per-slice checkpoint) ║
║  core/orchestrator/      ← execution_trace.json  (resume-from-failure)  ║
╚══════════════════════════════════════════════════════════════════════════╝
```

---

## Section 3 — Data Flow: Every Step

| # | Phase | Prompt file | Key input(s) | Artifact produced | Layer |
|---|-------|-------------|--------------|-------------------|-------|
| 0 | ENV CHECK | _(inline in entry prompt)_ | system env vars | `outputs/_common/env_check.md` | Entry |
| 1 | ACQUIRE | `prompts/common/git_clone.md` | `{{REPO_URL_OR_PATH}}`, PAT | `outputs/_common/repo_baseline.md` | Entry |
| 2 | SCAN | `prompts/common/repository_scan.md` | source code | `outputs/_common/repo_scan.json` | Scan |
| 3 | SCAN | `prompts/common/java_stack_profile.md` | `repo_scan.json` | `outputs/_common/java_stack_profile.md` | Scan |
| 4 | SCAN | `prompts/common/framework_classification.md` | `repo_scan.json` | `outputs/_common/framework_classification.json` | Scan |
| 5 | SCAN | _(inline: JSP route inventory)_ | source `@Controller` files | `outputs/_common/jsp_route_inventory.md` | Scan |
| 6 | PLAN | `prompts/common/global_context.md` + `core/context/brain_spec.md` | all scan artifacts | `core/context/global_context.json` | Brain |
| 7 | PLAN | `prompts/common/target_version_selection.md` | `migration_config.yaml` | `outputs/_common/target_version_selection.json` | Brain |
| 8 | PLAN | `prompts/common/spring_config_migration_mapping.md` | source + scan | `outputs/_common/spring_config_migration_mapping.md` | Scan |
| — | 🛑 **GATE 1** | _Human reviews scan results_ | `jsp_route_inventory`, `framework_classification` | _(confirmation)_ | HitL |
| 9 | PLAN | `prompts/wbs/jsp_to_react_wbs.md` | `global_context.json`, route inventory | `outputs/_global/generated_wbs.md` | WBS |
| 10 | PLAN | `prompts/common/wbs_router.md` | `generated_wbs.md` | `outputs/_global/wbs_execution_plan.json` | WBS |
| — | 🛑 **GATE 2** | _Human reviews WBS plan_ | `generated_wbs.md`, `wbs_execution_plan.json` | _(confirmation)_ | HitL |
| 11 | PLAN | `prompts/common/file_inventory_baseline.md` | source code | `outputs/_common/file_inventory_baseline.md` | Scan |
| 12×N | PLAN | `prompts/orchestration/skill_generator.md` | one WBS task entry | `outputs/_global/generated_skills/*_skill.md` | Skills |
| 12+ | PLAN | _(after all skills generated)_ | all skill files | `outputs/_global/skill_index.json` | Skills |
| — | 🛑 **GATE 3** | _Human spot-checks skill files_ | sampled skill files | _(confirmation)_ | HitL |
| 13 | APPLY | Each `*_skill.md` (CONTRACT order first) | skill prompt | source code changes + `skill_index.json` updates | Apply |
| 13t | APPLY | `prompts/orchestration/orchestration_trace.md` | `skill_index.json` | `core/orchestrator/execution_trace.json` | State |
| — | 🛑 **GATE 4** | _Human reviews after WEBUI, FORMS, COMPAT_ | live app + JSP fallback | _(confirmation)_ | HitL |
| 14 | VALIDATE | `QA-L01 skill` (Vitest + RTL) | components, mock fixtures | `outputs/_validation/qa_functional_<slice>.md` | Validate |
| 15 | VALIDATE | `QA-L02 skill` (visual regression) | screenshots | `outputs/_validation/visual_regression_<slice>.md` | Validate |
| 16 | VALIDATE | _(inline: `mvn clean install`)_ | source repo | `outputs/_validation/build_report.md` | Validate |
| 17 | STATE | `STATE-L01 skill` | QA results | `core/state/migration_state.json` | State |
| 18 | FINAL | `prompts/common/file_change_report.md` | all outputs | `outputs/_final/file_change_report.json` | Final |
| 19 | FINAL | `prompts/orchestration/mr_consolidation.md` | all module reports | `outputs/_final/merge_request_description.md` | Final |
| 20 | FINAL | `prompts/orchestration/html_report_generator.md` | all artifacts | `outputs/_final/migration_report.html` | Final |

---

## Section 4 — The Archetype System

The `skill_generator.md` uses an **Archetype Detection Table** to decide what kind of skill to write. It matches keywords in the task ID slug and title against the table below. The **first match wins**. Archetypes replace the old 60–150 word generic output with a 300–600 word skill containing real, named code skeletons.

| Keyword trigger(s) in task slug | Archetype | Min size | What the generated skill contains |
|---|---|---|---|
| `endpoint-impl`, `RestController` | **REST_API** | 400 words | `@RestController` class body, Java `record` DTO, `ResponseEntity<>` return, CSRF/CORS note, curl verification command |
| `react-host-scaffold`, `vite`, `scaffold` | **REACT_SCAFFOLD** | 400 words | `vite.config.ts` with proxy, `App.tsx` with React Router v6, `package.json` dependencies, Spring `ResourceHandlerRegistry` snippet |
| `look-feel`, `css`, `bootstrap`, `style` | **STYLE_PARITY** | 300 words | Bootstrap version note, JSP→React class mapping table, JSTL conditional → `className` conversion, screenshot checklist |
| `form-validation`, `form-nav`, `hook-form`, `zod` | **FORM_VALIDATION** | 400 words | `react-hook-form` + `zod` schema mirroring Spring Validation constraints, `setError` for server 400 responses, submit handler |
| `jstl-data-mock`, `mock`, `fixture` | **DATA_MOCK** | 300 words | TypeScript fixture file (`src/mocks/<Entity>Fixtures.ts`), `VITE_USE_MOCKS` env toggle, JSTL scan instructions |
| `functional-parity-tests`, `vitest`, `rtl` | **TEST_VALIDATION** | 400 words | 6 required test cases (empty state, data render, search, form success, form error, navigation), Vitest + RTL imports |
| `session-auth`, `csrf`, `cors`, `cookie` | **SESSION_COMPAT** | 300 words | `credentials:'include'` fetch config, Spring Security CORS bean, CSRF token fetch + `X-CSRF-TOKEN` header |
| `dto-field-mapping`, `contract`, `dto` | **DTO_CONTRACT** | 300 words | JSP `${model.*}` extraction table, TypeScript `interface`, field-level nullability and validation constraints |
| `error-page`, `error-boundary`, `404`, `500` | **ERROR_PARITY** | 300 words | React `ErrorBoundary` component, `useRouteError()` hook, mapping HTTP status codes to JSP error page equivalents |
| `commit-message`, `commitmsg` | **COMMIT_MSG** | 150 words | Conventional commit headers: Title, Summary, Files Changed, Change Log, Risks, Validation, Rollback Plan, Approvals Needed |
| _(no match)_ | **GENERIC** | 150 words | Standard skill fields only, no code skeleton |

### Why this matters for quality

Without archetypes, a skill generator produces output like:
> *"Implement the REST endpoint. Write the controller class. Add appropriate annotations."*

With archetypes, the same task produces a complete `@RestController` class body with the actual domain class name, actual service method name, and a working `curl` verification command — derived from the DTO contract and the JSP route inventory already collected in the SCAN phase.

---

## Section 5 — Safety Model

### 5.1 — G-02 JSP Fallback (Zero-Downtime Migration)

The JSP application is never broken during migration. The strategy:

```
Sprint Boot serves BOTH paths simultaneously:

  /owners/find        ──► @Controller  ──► findOwners.jsp   (ORIGINAL — always active)
  /react/owners/find  ──► React App    ──► React component  (NEW — being built)
  /api/owners         ──► @RestController ──► JSON            (ADAPTER — added only)
```

JSP routes are only removed in the final step of each slice, and **only when**:
- `QA-L01` (functional parity tests) = PASS
- `QA-L02` (visual regression check) = PASS
- Maven build = GREEN
- `STATE-L01` sets `fallback_active: false` in `migration_state.json`

### 5.2 — Guardrails Framework (`prompts/guardrails/guardrails_framework.md`)

Three risk levels with automatic stopping rules:

| Risk level | Trigger | Action |
|---|---|---|
| **BLOCKER** | Missing required config, phase mismatch, auth token placeholder still present, confidence < 0.70 | **Immediate stop.** Log to `outputs/_global/blockers.md`. Agent does not proceed until operator resolves. |
| **HIGH** | Unknown target version, missing spring config mapping, skipped validation | Stop and request human approval when `require_approval_for_high_risk=true` in `migration_config.yaml`. |
| **MEDIUM / LOW** | Minor assumptions, optional steps skipped | Record in artifact, continue. |

Additional hard rules enforced on every step:
- No destructive shell commands.
- No secrets printed in output (PAT/passwords redacted).
- No behavior changes without explicit approval.
- Output artifact written **first** before any narrative.
- Prompt-only execution — agent may not introduce logic not in a prompt file.

### 5.3 — Resume-from-Failure (`core/orchestrator/execution_trace.json`)

After every skill execution, the agent writes/updates `execution_trace.json`:

```json
{
  "run_id": "spring-mvc-jsp-petclinic-master_APPLY",
  "phase_status": {
    "SCAN":     "COMPLETE",
    "PLAN":     "COMPLETE",
    "APPLY":    "IN_PROGRESS",
    "VALIDATE": "NOT_RUN"
  },
  "completed_skills": ["CONTRACT-L01_...", "API-L01_...", "API-L02_..."],
  "failed_skills":    [],
  "skipped_skills":   [],
  "last_completed_skill": "API-L02_owners-endpoint-impl",
  "resume_from": "WEBUI-L01_react-host-scaffold",
  "blocker_detected": false
}
```

On session restart: the agent reads `resume_from`, skips all skills already in `completed_skills`, and announces the resume point. If `blocker_detected: true`, it requires explicit operator confirmation before proceeding.

---

## Section 6 — Directory Reference

```
prompt-wbs-automation-develop_brain/
│
├── SINGLE_COPY_PASTE_PROMPT_JSP_TO_REACT.md  ← START HERE. The only file the user needs to touch.
├── ARCHITECTURE.md                            ← This file.
├── README.md                                  ← High-level overview and target migration list.
├── AGENT_RUNBOOK.md                           ← Operational runbook for agent operators.
├── RUNBOOK.md                                 ← End-user runbook.
├── migration_config.yaml                      ← Master config: phase, targets, governance flags.
│
├── core/
│   ├── context/
│   │   ├── brain_spec.md          ← Decision rules (phase contracts, gating, stop conditions).
│   │   └── global_context.json    ← [GENERATED] Single "brain" artifact for the run.
│   ├── orchestrator/
│   │   └── execution_trace.json   ← [GENERATED] Resume-from-failure log.
│   ├── governance/                ← Governance artifacts (risk waivers, audit logs).
│   └── state/
│       ├── migration_state.json   ← [GENERATED] Per-slice checkpoint.
│       └── module_state.json      ← [GENERATED] Per-module status.
│
├── prompts/
│   ├── common/                    ← Reusable scan and plan prompts.
│   │   ├── repository_scan.md
│   │   ├── java_stack_profile.md
│   │   ├── framework_classification.md
│   │   ├── global_context.md
│   │   ├── target_version_selection.md
│   │   ├── spring_config_migration_mapping.md
│   │   ├── wbs_router.md
│   │   ├── file_inventory_baseline.md
│   │   ├── file_change_report.md
│   │   ├── git_clone.md
│   │   ├── state_checkpoint.md
│   │   └── route_inventory.md
│   ├── orchestration/             ← Orchestrator layer prompts.
│   │   ├── global_orchestrator.md
│   │   ├── module_orchestrator.md
│   │   ├── skill_generator.md     ← Archetype engine (10 templates).
│   │   ├── orchestration_trace.md
│   │   ├── mr_consolidation.md
│   │   └── html_report_generator.md
│   ├── wbs/                       ← Work breakdown structure generators.
│   │   └── jsp_to_react_wbs.md    ← 14 minimum tasks, 8 categories, all JSP scenarios.
│   ├── guardrails/
│   │   └── guardrails_framework.md
│   └── philosophy/
│       └── global_philosophy.md
│
├── outputs/                       ← [ALL GENERATED — never edit manually]
│   ├── _common/                   ← Scan phase artifacts (JSON/MD).
│   ├── _global/
│   │   ├── generated_wbs.md
│   │   ├── wbs_execution_plan.json
│   │   ├── skill_index.json
│   │   ├── generated_skills/      ← One *_skill.md per WBS task.
│   │   ├── module_reports/        ← One *_report.md per category.
│   │   └── blockers.md
│   ├── _validation/               ← QA and visual regression results.
│   └── _final/                    ← MR description, HTML report, commit message.
│
├── execution/                     ← Working copy of the target repo (cloned or copied here).
└── sampleJSPSpringboot app/       ← Reference app (PetClinic) for testing the framework.
```

---

## Section 7 — How to Demo Live to a Customer

Use this as a script. Each step tells you what to show on screen and what to say.

---

### Step 1 — Open the entry prompt (2 minutes)

**Show:** `SINGLE_COPY_PASTE_PROMPT_JSP_TO_REACT.md`

**Say:** *"This is the only file the user touches. They fill in five tokens — the repo URL or path, whether it's GitHub, GitLab, or a local folder, and an optional access token. Then they paste the whole file into their AI agent. That's it. Everything else is automated."*

**Point out:** The token table at the top. Show `{{SOURCE_TYPE}}` = `github` vs `filesystem`.

---

### Step 2 — Show the PetClinic source app (1 minute)

**Show:** `sampleJSPSpringboot app/spring-mvc-jsp-petclinic-master/src/main/webapp/WEB-INF/jsp/`

**Say:** *"This is a real legacy Spring Boot + JSP application. It has owner search, forms, pet management, vet listings — all rendered server-side with JSP. Our job is to move the entire frontend to React while keeping this backend completely untouched."*

---

### Step 3 — Run Phase 0 and Phase 1 (ENV + ACQUIRE) (2 minutes)

**Show:** Agent running ENV CHECK → output in `outputs/_common/env_check.md`

**Say:** *"The framework first validates the environment — Java, Node, Maven, Git. If anything is missing it stops with a clear BLOCKER code before touching any code. Then it either clones the repo or verifies the local path."*

---

### Step 4 — Run Phase 2 (SCAN) and hit Gate 1 (3 minutes)

**Show:** Agent producing `repo_scan.json`, `java_stack_profile.md`, `jsp_route_inventory.md`

**Say:** *"The scan phase fingerprints the entire application. It finds every JSP route, every Spring MVC controller, the Java version, Spring Boot version, every dependency. The JSP route inventory lists every page that needs to be migrated."*

**Show:** `🛑 GATE 1` in the prompt — the agent pauses.

**Say:** *"This is the first human checkpoint. The agent stops and asks: does this inventory look right? The customer can add or remove routes before the plan is generated. Nothing proceeds without explicit confirmation."*

---

### Step 5 — Run Phase 3 (PLAN) and hit Gates 2 and 3 (4 minutes)

**Show:** `outputs/_global/generated_wbs.md` — the full task list

**Say:** *"The Work Breakdown Structure is generated automatically from the route inventory. For the Owners slice it creates: DTO contract extraction, REST endpoint plan, REST endpoint implementation, React scaffold, component build, look-and-feel parity, form validation, navigation parity, session compatibility, error pages, functional tests, visual regression, and a commit message. Every scenario is covered."*

**Show:** `🛑 GATE 2` — agent pauses again.

**Show:** One generated skill file, e.g. `outputs/_global/generated_skills/API-L02_owners-endpoint-impl_skill.md`

**Say:** *"Now look at the quality of this generated skill. It contains the actual `@RestController` class body pre-populated with the correct class names from the scan. It's not generic instructions — it's a ready-to-apply code template. This is the Archetype engine at work."*

**Show:** `🛑 GATE 3` — agent pauses for skill review.

---

### Step 6 — Run Phase 4 (APPLY) with Gate 4 (5 minutes)

**Show:** Agent applying CONTRACT skills → API skills → WEBUI skills in order

**Say:** *"Skills execute in a strict category order enforced by the WBS router: CONTRACT first, then API, then WEBUI, then FORMS, then COMPAT. Each skill tells the agent exactly what file to create or modify, what code to write, and what the Status field must say when done."*

**Show (if available):** The Spring Boot app still serving `/owners/find` as JSP while `/react/owners/find` is being built.

**Say:** *"Notice the original JSP application is still running perfectly. The React app is being built at a separate path. This is the G-02 fallback rule — the customer's production app is never broken during the migration."*

**Show:** `🛑 GATE 4` after WEBUI category.

---

### Step 7 — Run Phase 5 (VALIDATE) (3 minutes)

**Show:** `outputs/_validation/qa_functional_owners.md` — test results

**Show:** `outputs/_validation/visual_regression_owners.md` — screenshot comparison

**Say:** *"Validation runs three things: Vitest functional tests that mirror the exact JSP user paths, a visual regression check comparing screenshots of the JSP page and the React page, and a Maven build to confirm the backend still compiles. Only when all three pass does the framework remove the JSP fallback for this slice."*

---

### Step 8 — Show the final reports (2 minutes)

**Show:** `outputs/_final/migration_report.html` — open in a browser

**Show:** `outputs/_final/merge_request_description.md`

**Say:** *"The consolidation phase produces a static HTML report listing every module result, risk, artifact, and file changed — ready to attach to a Jira ticket or email. It also generates a structured Merge Request description with a rollback plan built in."*

---

### Step 9 — Show resume-from-failure (1 minute)

**Show:** `core/orchestrator/execution_trace.json` — highlight `resume_from`

**Say:** *"If the session crashes or the operator needs to pause, the trace file records exactly where we are. On restart the agent reads this file, announces 'resuming from skill X, skipping 12 already-applied skills', and continues from the exact breakpoint. No work is lost and no step is accidentally repeated."*

---

### Step 10 — Explain next slice (1 minute)

**Say:** *"After the Owners slice is complete and validated, we update one field in the global context — `current_slice` — and re-run from the WBS generation step. The scan is reused. The React scaffold is already in place. The next slice — Vets, Pets, Visits — takes half the time of the first because the infrastructure is already there."*

---

### Total demo time: ~25 minutes

**Key messages to leave with the customer:**
1. **One file to fill in.** No scripts, no config files beyond the token table.
2. **Four safety checkpoints.** The customer stays in control at every major decision point.
3. **Zero-downtime.** The live JSP app never breaks during migration.
4. **Deterministic output.** Run the same prompt twice, get the same files. No surprises.
5. **Resumable.** A crash or interruption loses nothing. The trace file handles restart.
